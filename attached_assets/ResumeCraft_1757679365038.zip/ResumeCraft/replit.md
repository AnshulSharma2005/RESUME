# Overview

ResumeForge is a modern web application that helps users create professional, ATS-optimized resumes. The application features a React frontend with a user-friendly interface for template selection, customization, and ATS scoring analysis. Users can sign up with Firebase authentication, choose from career-level specific templates, customize their resume appearance, and get feedback on ATS compatibility.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture
The application uses a React-based single page application (SPA) architecture built with Vite as the build tool. The frontend follows a component-based design pattern using:
- **React Router**: Implemented with Wouter for lightweight client-side routing
- **State Management**: React Query (TanStack Query) for server state management and React hooks for local state
- **UI Framework**: Shadcn/ui components built on Radix UI primitives with Tailwind CSS for styling
- **Authentication Flow**: Firebase Authentication integration with custom auth context provider

## Backend Architecture
The backend follows a REST API pattern using Express.js:
- **API Structure**: RESTful endpoints for users, resumes, and ATS reports
- **Data Layer**: Abstract storage interface with in-memory implementation for development
- **Request Handling**: Express middleware for JSON parsing, logging, and error handling
- **Development Setup**: Vite integration for hot module replacement in development

## Authentication System
Firebase Authentication is used for user management:
- **Authentication Methods**: Email/password signup and signin
- **User Context**: React context provider wraps the application to provide authentication state
- **Authorization**: Bearer token validation using Firebase UID in API requests
- **User Profile**: Firebase user profiles linked to application user records

## Database Schema
The application uses Drizzle ORM with PostgreSQL:
- **Users Table**: Stores user profiles with Firebase UID mapping and career level
- **Resumes Table**: Stores resume content, templates, and customization settings
- **ATS Reports Table**: Stores analysis results and scoring data
- **Relationships**: Foreign key relationships between users, resumes, and reports

## Template System
Template management follows a category-based approach:
- **Career Level Filtering**: Templates categorized by beginner, mid-career, and professional levels
- **Customization Options**: Color themes, font selections, and layout variations
- **Preview Generation**: Real-time resume preview with applied customizations
- **PDF Export**: HTML-to-canvas conversion for PDF generation

## ATS Analysis Engine
The ATS scoring system provides resume optimization feedback:
- **Keyword Analysis**: Industry-specific keyword matching against predefined dictionaries
- **Format Compatibility**: Checks for ATS-friendly formatting patterns
- **Action Verb Detection**: Identifies strong action verbs in resume content
- **Scoring Algorithm**: Multi-factor scoring with breakdown by optimization categories

## External Dependencies

- **Firebase**: Authentication service and user management
- **Neon Database**: PostgreSQL database hosting (configured via DATABASE_URL)
- **Radix UI**: Accessible component primitives for the design system
- **PDF.js**: Client-side PDF processing for resume uploads
- **jsPDF**: PDF generation from HTML content
- **html2canvas**: Canvas rendering for PDF export functionality
- **Drizzle ORM**: Type-safe database query builder and migration management