import { sql } from "drizzle-orm";
import { pgTable, text, varchar, timestamp, jsonb, integer } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  firebaseUid: text("firebase_uid").notNull().unique(),
  email: text("email").notNull().unique(),
  displayName: text("display_name").notNull(),
  careerLevel: text("career_level").$type<"beginner" | "mid-career" | "professional">(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const resumes = pgTable("resumes", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").references(() => users.id).notNull(),
  title: text("title").notNull(),
  templateId: text("template_id").notNull(),
  content: jsonb("content").notNull(),
  customization: jsonb("customization").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const atsReports = pgTable("ats_reports", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").references(() => users.id).notNull(),
  resumeId: varchar("resume_id").references(() => resumes.id),
  score: integer("score").notNull(),
  analysis: jsonb("analysis").notNull(),
  attemptsUsed: integer("attempts_used").default(1).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  firebaseUid: true,
  email: true,
  displayName: true,
  careerLevel: true,
});

export const insertResumeSchema = createInsertSchema(resumes).pick({
  userId: true,
  title: true,
  templateId: true,
  content: true,
  customization: true,
});

export const insertAtsReportSchema = createInsertSchema(atsReports).pick({
  userId: true,
  resumeId: true,
  score: true,
  analysis: true,
  attemptsUsed: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type InsertResume = z.infer<typeof insertResumeSchema>;
export type Resume = typeof resumes.$inferSelect;
export type InsertAtsReport = z.infer<typeof insertAtsReportSchema>;
export type AtsReport = typeof atsReports.$inferSelect;
