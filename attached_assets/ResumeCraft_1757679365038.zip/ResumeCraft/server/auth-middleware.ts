import type { Request, Response, NextFunction } from "express";
import { verifyFirebaseToken } from "./firebase-admin";
import { storage } from "./storage";

// Extend Request interface to include user data
declare global {
  namespace Express {
    interface Request {
      user?: {
        uid: string;
        email?: string;
        name?: string;
        dbUser?: any;
      };
    }
  }
}

export async function authenticateFirebaseToken(
  req: Request,
  res: Response,
  next: NextFunction
) {
  try {
    const authHeader = req.headers.authorization;
    if (!authHeader?.startsWith("Bearer ")) {
      return res.status(401).json({ message: "No valid authorization token provided" });
    }

    const token = authHeader.replace("Bearer ", "");
    const decodedToken = await verifyFirebaseToken(token);

    // Add user data to request
    req.user = {
      uid: decodedToken.uid,
      email: decodedToken.email,
      name: decodedToken.name,
    };

    // Try to get user from database
    const dbUser = await storage.getUserByFirebaseUid(decodedToken.uid);
    if (dbUser) {
      req.user.dbUser = dbUser;
    }

    next();
  } catch (error) {
    console.error("Firebase token verification failed:", error);
    return res.status(401).json({ message: "Invalid or expired token" });
  }
}