import { type User, type InsertUser, type Resume, type InsertResume, type AtsReport, type InsertAtsReport } from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  // User methods
  getUser(id: string): Promise<User | undefined>;
  getUserByFirebaseUid(firebaseUid: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUserCareerLevel(firebaseUid: string, careerLevel: string): Promise<User | undefined>;
  
  // Resume methods
  createResume(resume: InsertResume): Promise<Resume>;
  getResume(id: string): Promise<Resume | undefined>;
  getResumesByUserId(userId: string): Promise<Resume[]>;
  updateResume(id: string, updates: Partial<Resume>): Promise<Resume | undefined>;
  
  // ATS Report methods
  createAtsReport(report: InsertAtsReport): Promise<AtsReport>;
  getAtsReportsByUserId(userId: string): Promise<AtsReport[]>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private resumes: Map<string, Resume>;
  private atsReports: Map<string, AtsReport>;

  constructor() {
    this.users = new Map();
    this.resumes = new Map();
    this.atsReports = new Map();
  }

  // User methods
  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByFirebaseUid(firebaseUid: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.firebaseUid === firebaseUid,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = { 
      ...insertUser, 
      id,
      careerLevel: (insertUser.careerLevel as "beginner" | "mid-career" | "professional") || null,
      createdAt: new Date()
    };
    this.users.set(id, user);
    return user;
  }

  async updateUserCareerLevel(firebaseUid: string, careerLevel: string): Promise<User | undefined> {
    const user = await this.getUserByFirebaseUid(firebaseUid);
    if (!user) return undefined;

    const updatedUser: User = {
      ...user,
      careerLevel: careerLevel as "beginner" | "mid-career" | "professional"
    };

    this.users.set(user.id, updatedUser);
    return updatedUser;
  }

  // Resume methods
  async createResume(insertResume: InsertResume): Promise<Resume> {
    const id = randomUUID();
    const now = new Date();
    const resume: Resume = {
      ...insertResume,
      id,
      createdAt: now,
      updatedAt: now
    };
    this.resumes.set(id, resume);
    return resume;
  }

  async getResume(id: string): Promise<Resume | undefined> {
    return this.resumes.get(id);
  }

  async getResumesByUserId(userId: string): Promise<Resume[]> {
    return Array.from(this.resumes.values()).filter(
      (resume) => resume.userId === userId
    );
  }

  async updateResume(id: string, updates: Partial<Resume>): Promise<Resume | undefined> {
    const resume = this.resumes.get(id);
    if (!resume) return undefined;

    const updatedResume: Resume = {
      ...resume,
      ...updates,
      updatedAt: new Date()
    };

    this.resumes.set(id, updatedResume);
    return updatedResume;
  }

  // ATS Report methods
  async createAtsReport(insertReport: InsertAtsReport): Promise<AtsReport> {
    const id = randomUUID();
    const report: AtsReport = {
      ...insertReport,
      id,
      resumeId: insertReport.resumeId || null,
      attemptsUsed: insertReport.attemptsUsed || 1,
      createdAt: new Date()
    };
    this.atsReports.set(id, report);
    return report;
  }

  async getAtsReportsByUserId(userId: string): Promise<AtsReport[]> {
    return Array.from(this.atsReports.values()).filter(
      (report) => report.userId === userId
    );
  }
}

// Use in-memory storage for reliable development
export const storage: IStorage = new MemStorage();
