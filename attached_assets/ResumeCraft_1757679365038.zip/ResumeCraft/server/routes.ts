import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertUserSchema, insertResumeSchema, insertAtsReportSchema } from "@shared/schema";
import { z } from "zod";
import { authenticateFirebaseToken } from "./auth-middleware";

export async function registerRoutes(app: Express): Promise<Server> {
  // User routes
  app.post("/api/users", async (req, res) => {
    try {
      const userData = insertUserSchema.parse(req.body);
      const user = await storage.createUser(userData);
      res.json(user);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid user data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create user" });
    }
  });

  app.get("/api/users/me", authenticateFirebaseToken, async (req, res) => {
    try {
      let user = req.user?.dbUser;
      
      // If user doesn't exist in database, create them
      if (!user && req.user) {
        const userData = {
          firebaseUid: req.user.uid,
          email: req.user.email || '',
          displayName: req.user.name || 'User',
        };
        
        try {
          user = await storage.createUser(userData);
          req.user.dbUser = user;
        } catch (createError) {
          console.error('Error creating user:', createError);
          return res.status(500).json({ message: "Failed to create user" });
        }
      }
      
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      res.json(user);
    } catch (error) {
      console.error('Error getting user:', error);
      res.status(500).json({ message: "Failed to get user" });
    }
  });

  app.patch("/api/users/career-level", authenticateFirebaseToken, async (req, res) => {
    try {
      const { careerLevel } = req.body;
      if (!careerLevel || !["beginner", "mid-career", "professional"].includes(careerLevel)) {
        return res.status(400).json({ message: "Invalid career level" });
      }

      const user = await storage.updateUserCareerLevel(req.user!.uid, careerLevel);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      res.json(user);
    } catch (error) {
      console.error('Error updating career level:', error);
      res.status(500).json({ message: "Failed to update career level" });
    }
  });

  // Resume routes
  app.post("/api/resumes", authenticateFirebaseToken, async (req, res) => {
    try {
      if (!req.user?.dbUser) {
        return res.status(404).json({ message: "User not found" });
      }

      const resumeData = insertResumeSchema.parse({ ...req.body, userId: req.user.dbUser.id });
      const resume = await storage.createResume(resumeData);
      res.json(resume);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid resume data", errors: error.errors });
      }
      console.error('Error creating resume:', error);
      res.status(500).json({ message: "Failed to create resume" });
    }
  });

  app.get("/api/resumes", authenticateFirebaseToken, async (req, res) => {
    try {
      if (!req.user?.dbUser) {
        return res.status(404).json({ message: "User not found" });
      }

      const resumes = await storage.getResumesByUserId(req.user.dbUser.id);
      res.json(resumes);
    } catch (error) {
      console.error('Error getting resumes:', error);
      res.status(500).json({ message: "Failed to get resumes" });
    }
  });

  app.get("/api/resumes/:id", async (req, res) => {
    try {
      const firebaseUid = req.headers.authorization?.replace("Bearer ", "");
      if (!firebaseUid) {
        return res.status(401).json({ message: "Unauthorized" });
      }

      const resume = await storage.getResume(req.params.id);
      if (!resume) {
        return res.status(404).json({ message: "Resume not found" });
      }

      // Verify ownership
      const user = await storage.getUserByFirebaseUid(firebaseUid);
      if (!user || resume.userId !== user.id) {
        return res.status(403).json({ message: "Forbidden" });
      }

      res.json(resume);
    } catch (error) {
      res.status(500).json({ message: "Failed to get resume" });
    }
  });

  // ATS Report routes
  app.post("/api/ats-reports", async (req, res) => {
    try {
      const firebaseUid = req.headers.authorization?.replace("Bearer ", "");
      if (!firebaseUid) {
        return res.status(401).json({ message: "Unauthorized" });
      }

      const user = await storage.getUserByFirebaseUid(firebaseUid);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      const reportData = insertAtsReportSchema.parse({ ...req.body, userId: user.id });
      const report = await storage.createAtsReport(reportData);
      res.json(report);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid report data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create ATS report" });
    }
  });

  app.get("/api/ats-reports", async (req, res) => {
    try {
      const firebaseUid = req.headers.authorization?.replace("Bearer ", "");
      if (!firebaseUid) {
        return res.status(401).json({ message: "Unauthorized" });
      }

      const user = await storage.getUserByFirebaseUid(firebaseUid);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      const reports = await storage.getAtsReportsByUserId(user.id);
      res.json(reports);
    } catch (error) {
      res.status(500).json({ message: "Failed to get ATS reports" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
