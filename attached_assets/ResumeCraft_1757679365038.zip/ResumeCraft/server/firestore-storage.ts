import { adminDb } from "./firebase-admin";
import { type User, type InsertUser, type Resume, type InsertResume, type AtsReport, type InsertAtsReport } from "@shared/schema";
import type { IStorage } from "./storage";

export class FirestoreStorage implements IStorage {
  private usersCollection = adminDb.collection('users');
  private resumesCollection = adminDb.collection('resumes');
  private atsReportsCollection = adminDb.collection('ats_reports');

  // User methods
  async getUser(id: string): Promise<User | undefined> {
    try {
      const doc = await this.usersCollection.doc(id).get();
      if (!doc.exists) return undefined;
      return { id: doc.id, ...doc.data() } as User;
    } catch (error) {
      console.error('Error getting user:', error);
      return undefined;
    }
  }

  async getUserByFirebaseUid(firebaseUid: string): Promise<User | undefined> {
    try {
      const query = await this.usersCollection.where('firebaseUid', '==', firebaseUid).limit(1).get();
      if (query.empty) return undefined;
      
      const doc = query.docs[0];
      return { id: doc.id, ...doc.data() } as User;
    } catch (error) {
      console.error('Error getting user by Firebase UID:', error);
      return undefined;
    }
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    try {
      const docRef = await this.usersCollection.add({
        ...insertUser,
        careerLevel: insertUser.careerLevel || null,
        createdAt: new Date()
      });
      
      const doc = await docRef.get();
      return { id: doc.id, ...doc.data() } as User;
    } catch (error) {
      console.error('Error creating user:', error);
      throw new Error('Failed to create user');
    }
  }

  async updateUserCareerLevel(firebaseUid: string, careerLevel: string): Promise<User | undefined> {
    try {
      const user = await this.getUserByFirebaseUid(firebaseUid);
      if (!user) return undefined;

      await this.usersCollection.doc(user.id).update({
        careerLevel: careerLevel as "beginner" | "mid-career" | "professional"
      });

      return this.getUser(user.id);
    } catch (error) {
      console.error('Error updating user career level:', error);
      return undefined;
    }
  }

  // Resume methods
  async createResume(insertResume: InsertResume): Promise<Resume> {
    try {
      const now = new Date();
      const docRef = await this.resumesCollection.add({
        ...insertResume,
        createdAt: now,
        updatedAt: now
      });

      const doc = await docRef.get();
      return { id: doc.id, ...doc.data() } as Resume;
    } catch (error) {
      console.error('Error creating resume:', error);
      throw new Error('Failed to create resume');
    }
  }

  async getResume(id: string): Promise<Resume | undefined> {
    try {
      const doc = await this.resumesCollection.doc(id).get();
      if (!doc.exists) return undefined;
      return { id: doc.id, ...doc.data() } as Resume;
    } catch (error) {
      console.error('Error getting resume:', error);
      return undefined;
    }
  }

  async getResumesByUserId(userId: string): Promise<Resume[]> {
    try {
      const query = await this.resumesCollection.where('userId', '==', userId).get();
      return query.docs.map(doc => ({ id: doc.id, ...doc.data() } as Resume));
    } catch (error) {
      console.error('Error getting resumes by user ID:', error);
      return [];
    }
  }

  async updateResume(id: string, updates: Partial<Resume>): Promise<Resume | undefined> {
    try {
      await this.resumesCollection.doc(id).update({
        ...updates,
        updatedAt: new Date()
      });

      return this.getResume(id);
    } catch (error) {
      console.error('Error updating resume:', error);
      return undefined;
    }
  }

  // ATS Report methods
  async createAtsReport(insertReport: InsertAtsReport): Promise<AtsReport> {
    try {
      const docRef = await this.atsReportsCollection.add({
        ...insertReport,
        resumeId: insertReport.resumeId || null,
        attemptsUsed: insertReport.attemptsUsed || 1,
        createdAt: new Date()
      });

      const doc = await docRef.get();
      return { id: doc.id, ...doc.data() } as AtsReport;
    } catch (error) {
      console.error('Error creating ATS report:', error);
      throw new Error('Failed to create ATS report');
    }
  }

  async getAtsReportsByUserId(userId: string): Promise<AtsReport[]> {
    try {
      const query = await this.atsReportsCollection.where('userId', '==', userId).get();
      return query.docs.map(doc => ({ id: doc.id, ...doc.data() } as AtsReport));
    } catch (error) {
      console.error('Error getting ATS reports by user ID:', error);
      return [];
    }
  }
}