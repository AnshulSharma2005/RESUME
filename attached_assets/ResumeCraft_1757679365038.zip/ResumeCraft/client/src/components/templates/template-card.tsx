import { Card, CardContent } from "@/components/ui/card";
import { Template } from "@/data/templates";
import { cn } from "@/lib/utils";

interface TemplateCardProps {
  template: Template;
  onSelect: (templateId: string) => void;
  selected?: boolean;
}

export function TemplateCard({ template, onSelect, selected }: TemplateCardProps) {
  const vibrantGradients: Record<string, string> = {
    blue: "gradient-cyan",
    green: "gradient-green",
    purple: "gradient-purple",
    orange: "gradient-orange",
    red: "gradient-orange",
    teal: "gradient-cyan",
    indigo: "gradient-purple",
    gray: "bg-gradient-to-br from-gray-400 to-gray-600",
  };
  const gradientClass = vibrantGradients[template.color] || "gradient-purple";

  const animationDelays = ['0s', '0.1s', '0.2s', '0.3s', '0.4s', '0.5s'];
  const randomDelay = animationDelays[Math.floor(Math.random() * animationDelays.length)];

  return (
    <Card 
      className={cn(
        "cursor-pointer template-card hover-lift border-gradient bg-gradient-to-br from-card to-secondary/20 group relative overflow-hidden",
        selected && "ring-2 ring-primary border-gradient"
      )}
      onClick={() => onSelect(template.id)}
      data-testid={`card-template-${template.id}`}
      style={{ animationDelay: randomDelay }}
    >
      {/* Selection glow effect */}
      {selected && (
        <div className="absolute inset-0 bg-gradient-to-br from-primary/20 to-accent/20 animate-pulse"></div>
      )}
      
      <CardContent className="p-4 relative z-10">
        <div className={cn(
          "h-44 rounded-lg mb-4 flex items-center justify-center relative overflow-hidden group-hover:scale-105 transition-transform duration-300", 
          gradientClass
        )}>
          {/* Floating animation overlay */}
          <div className="absolute inset-0 bg-gradient-to-t from-black/10 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
          
          {/* Template preview mockup */}
          <div className="text-center relative z-10">
            <div className="w-20 h-3 mb-2 rounded-full bg-white/90 shadow-lg animate-pulse"></div>
            <div className="bg-white/60 w-16 h-1.5 mb-1.5 rounded mx-auto"></div>
            <div className="bg-white/60 w-18 h-1.5 mb-3 rounded mx-auto"></div>
            <div className="bg-white/60 w-14 h-1 mb-1 rounded mx-auto"></div>
            <div className="bg-white/60 w-12 h-1 rounded mx-auto"></div>
            
            {/* Floating sparkle effect */}
            <div className="absolute top-2 right-2 w-2 h-2 bg-white rounded-full animate-ping opacity-75"></div>
            <div className="absolute bottom-3 left-3 w-1.5 h-1.5 bg-white rounded-full animate-ping opacity-50" style={{animationDelay: '0.5s'}}></div>
          </div>
        </div>
        
        <div className="text-center">
          <h3 className="font-bold text-base text-gradient mb-2 group-hover:scale-105 transition-transform" data-testid={`text-template-name-${template.id}`}>
            {template.name}
          </h3>
          <p className="text-xs text-muted-foreground leading-relaxed" data-testid={`text-template-description-${template.id}`}>
            {template.description}
          </p>
          
          {/* Interactive selection indicator */}
          <div className={cn(
            "mt-3 h-1 rounded-full transition-all duration-300",
            selected 
              ? "bg-gradient-to-r from-primary to-accent scale-100" 
              : "bg-muted/30 scale-75 group-hover:scale-90"
          )}></div>
        </div>
        
        {/* Hover glow effect */}
        <div className="absolute inset-0 bg-gradient-to-br from-primary/5 to-accent/5 opacity-0 group-hover:opacity-100 transition-opacity duration-300 rounded-lg"></div>
      </CardContent>
    </Card>
  );
}
