import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

interface FontSelectorProps {
  selectedFont: string;
  onFontChange: (font: string) => void;
}

const fonts = [
  { value: "inter", label: "Inter (Modern)" },
  { value: "times", label: "Times New Roman (Classic)" },
  { value: "arial", label: "Arial (Clean)" },
  { value: "helvetica", label: "Helvetica (Professional)" },
  { value: "georgia", label: "Georgia (Elegant)" },
];

export function FontSelector({ selectedFont, onFontChange }: FontSelectorProps) {
  return (
    <div>
      <h3 className="font-semibold text-foreground mb-3">Font Style</h3>
      <Select value={selectedFont} onValueChange={onFontChange}>
        <SelectTrigger data-testid="select-font">
          <SelectValue placeholder="Select font" />
        </SelectTrigger>
        <SelectContent>
          {fonts.map((font) => (
            <SelectItem 
              key={font.value} 
              value={font.value}
              data-testid={`option-font-${font.value}`}
            >
              {font.label}
            </SelectItem>
          ))}
        </SelectContent>
      </Select>
    </div>
  );
}
