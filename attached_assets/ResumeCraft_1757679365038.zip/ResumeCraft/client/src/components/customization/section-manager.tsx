import { Button } from "@/components/ui/button";
import { GripVertical, Eye, EyeOff, Plus } from "lucide-react";
import { cn } from "@/lib/utils";

interface Section {
  id: string;
  name: string;
  visible: boolean;
  order: number;
}

interface SectionManagerProps {
  sections: Section[];
  onToggleVisibility: (sectionId: string) => void;
  onReorder: (sections: Section[]) => void;
  onAddSection: () => void;
}

export function SectionManager({ sections, onToggleVisibility, onReorder, onAddSection }: SectionManagerProps) {
  return (
    <div>
      <h3 className="font-semibold text-foreground mb-3">Resume Sections</h3>
      <div className="space-y-2">
        {sections.map((section) => (
          <div
            key={section.id}
            className="flex items-center justify-between p-2 bg-muted rounded"
            data-testid={`section-${section.id}`}
          >
            <span className="text-sm" data-testid={`text-section-${section.id}`}>
              {section.name}
            </span>
            <div className="flex items-center space-x-2">
              <Button
                variant="ghost"
                size="sm"
                className="text-muted-foreground hover:text-foreground p-1"
                data-testid={`button-grip-${section.id}`}
              >
                <GripVertical className="h-4 w-4" />
              </Button>
              <Button
                variant="ghost"
                size="sm"
                className="text-muted-foreground hover:text-foreground p-1"
                onClick={() => onToggleVisibility(section.id)}
                data-testid={`button-visibility-${section.id}`}
              >
                {section.visible ? <Eye className="h-4 w-4" /> : <EyeOff className="h-4 w-4" />}
              </Button>
            </div>
          </div>
        ))}
      </div>
      
      <Button
        variant="outline"
        className="w-full mt-3 text-primary border-primary hover:bg-primary/5 transition-colors text-sm"
        onClick={onAddSection}
        data-testid="button-add-section"
      >
        <Plus className="h-4 w-4 mr-2" />
        Add Section
      </Button>
    </div>
  );
}
