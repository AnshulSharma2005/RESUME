import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

interface ColorPickerProps {
  selectedColor: string;
  onColorChange: (color: string) => void;
}

const colors = [
  { name: "blue", class: "bg-blue-500" },
  { name: "green", class: "bg-green-500" },
  { name: "purple", class: "bg-purple-500" },
  { name: "red", class: "bg-red-500" },
  { name: "orange", class: "bg-orange-500" },
  { name: "teal", class: "bg-teal-500" },
  { name: "pink", class: "bg-pink-500" },
  { name: "indigo", class: "bg-indigo-500" },
  { name: "yellow", class: "bg-yellow-500" },
  { name: "gray", class: "bg-gray-700" },
];

export function ColorPicker({ selectedColor, onColorChange }: ColorPickerProps) {
  return (
    <div>
      <h3 className="font-semibold text-foreground mb-3">Theme Colors</h3>
      <div className="grid grid-cols-5 gap-2">
        {colors.map((color) => (
          <Button
            key={color.name}
            variant="ghost"
            size="sm"
            className={cn(
              "w-8 h-8 rounded-full border-2 border-white shadow-md hover:scale-110 transition-transform p-0",
              color.class,
              selectedColor === color.name && "ring-2 ring-primary ring-offset-2"
            )}
            onClick={() => onColorChange(color.name)}
            data-testid={`button-color-${color.name}`}
          />
        ))}
      </div>
    </div>
  );
}
