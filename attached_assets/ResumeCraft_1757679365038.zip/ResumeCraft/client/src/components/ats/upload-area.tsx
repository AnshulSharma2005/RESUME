import { useCallback } from "react";
import { useDropzone } from "react-dropzone";
import { Button } from "@/components/ui/button";
import { CloudUpload } from "lucide-react";
import { cn } from "@/lib/utils";

interface UploadAreaProps {
  onFileUpload: (file: File) => void;
  loading?: boolean;
}

export function UploadArea({ onFileUpload, loading }: UploadAreaProps) {
  const onDrop = useCallback((acceptedFiles: File[]) => {
    if (acceptedFiles.length > 0) {
      onFileUpload(acceptedFiles[0]);
    }
  }, [onFileUpload]);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: {
      'application/pdf': ['.pdf']
    },
    maxSize: 10 * 1024 * 1024, // 10MB
    multiple: false
  });

  return (
    <div
      {...getRootProps()}
      className={cn(
        "border-2 border-dashed border-border rounded-lg p-12 text-center cursor-pointer transition-colors",
        isDragActive && "border-primary bg-primary/5",
        loading && "opacity-50 cursor-not-allowed"
      )}
      data-testid="upload-area"
    >
      <input {...getInputProps()} />
      <div className="max-w-md mx-auto">
        <CloudUpload className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
        <h3 className="text-xl font-semibold text-foreground mb-2" data-testid="text-upload-title">
          Upload Your Resume
        </h3>
        <p className="text-muted-foreground mb-4" data-testid="text-upload-description">
          {isDragActive ? "Drop your PDF file here" : "Drop your PDF file here or click to browse"}
        </p>
        <Button
          variant="default"
          disabled={loading}
          data-testid="button-choose-file"
        >
          {loading ? "Processing..." : "Choose File"}
        </Button>
        <p className="text-xs text-muted-foreground mt-2">
          Supports PDF files up to 10MB
        </p>
      </div>
    </div>
  );
}
