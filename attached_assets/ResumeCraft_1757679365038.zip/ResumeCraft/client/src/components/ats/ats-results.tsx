import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { CheckCircle, AlertTriangle, Download, Edit } from "lucide-react";
import { ATSAnalysis } from "@/utils/ats-scorer";

interface ATSResultsProps {
  analysis: ATSAnalysis;
  attemptsRemaining: number;
  onEditResume: () => void;
  onDownloadReport: () => void;
}

export function ATSResults({ analysis, attemptsRemaining, onEditResume, onDownloadReport }: ATSResultsProps) {
  const getScoreGradient = (score: number) => {
    if (score >= 80) return "gradient-green";
    if (score >= 60) return "gradient-orange";
    return "bg-gradient-to-br from-red-500 to-pink-500";
  };

  const getScoreBgGradient = (score: number) => {
    if (score >= 80) return "bg-gradient-to-br from-green-50 to-emerald-100";
    if (score >= 60) return "bg-gradient-to-br from-orange-50 to-yellow-100";
    return "bg-gradient-to-br from-red-50 to-pink-100";
  };

  const getProgressGradient = (score: number) => {
    if (score >= 80) return "gradient-green";
    if (score >= 60) return "gradient-orange";
    return "bg-gradient-to-r from-red-500 to-pink-500";
  };

  return (
    <Card data-testid="ats-results">
      <CardContent className="p-8">
        {/* Overall Score */}
        <div className="text-center mb-12 animate-bounce-in">
          <div className={`inline-flex items-center justify-center w-32 h-32 rounded-full mb-6 ${getScoreBgGradient(analysis.score)} border-4 border-white shadow-2xl hover-pulse relative`}>
            <div className={`absolute inset-2 rounded-full ${getScoreGradient(analysis.score)} flex items-center justify-center`}>
              <span className="text-4xl font-bold text-white" data-testid="text-ats-score">
                {analysis.score}
              </span>
            </div>
            {/* Floating sparkles */}
            <div className="absolute top-0 right-2 w-3 h-3 bg-yellow-400 rounded-full animate-ping"></div>
            <div className="absolute bottom-2 left-0 w-2 h-2 bg-white rounded-full animate-ping" style={{animationDelay: '0.5s'}}></div>
          </div>
          
          <h2 className="text-4xl font-bold mb-4 text-gradient" data-testid="text-ats-score-title">
            ATS Score: {analysis.score}/100
          </h2>
          
          {/* Progress bar */}
          <div className="max-w-md mx-auto mb-4">
            <div className="w-full bg-muted rounded-full h-3 overflow-hidden">
              <div 
                className={`h-full transition-all duration-1000 ease-out ${getProgressGradient(analysis.score)} relative`}
                style={{width: `${analysis.score}%`}}
              >
                <div className="absolute inset-0 bg-white/20 animate-pulse"></div>
              </div>
            </div>
          </div>
          
          <div className="inline-block px-6 py-3 rounded-full bg-gradient-to-r from-card to-secondary/50 border-gradient">
            <p className="text-lg font-medium text-foreground" data-testid="text-ats-score-description">
              {analysis.score >= 80 ? "🎉 Excellent! Your resume is highly ATS-friendly" :
               analysis.score >= 60 ? "👍 Good! Your resume is ATS-friendly with room for improvement" :
               "📈 Your resume needs improvement to be ATS-friendly"}
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Strengths */}
          <div>
            <h3 className="text-lg font-semibold text-foreground mb-4 flex items-center">
              <CheckCircle className="text-green-500 mr-2" />
              Strengths
            </h3>
            <ul className="space-y-2" data-testid="list-strengths">
              {analysis.strengths.map((strength, index) => (
                <li key={index} className="flex items-start space-x-2" data-testid={`strength-${index}`}>
                  <CheckCircle className="text-green-500 mt-1 h-4 w-4 flex-shrink-0" />
                  <span className="text-muted-foreground">{strength}</span>
                </li>
              ))}
            </ul>
          </div>

          {/* Improvements */}
          <div>
            <h3 className="text-lg font-semibold text-foreground mb-4 flex items-center">
              <AlertTriangle className="text-yellow-500 mr-2" />
              Improvements
            </h3>
            <ul className="space-y-2" data-testid="list-improvements">
              {analysis.improvements.map((improvement, index) => (
                <li key={index} className="flex items-start space-x-2" data-testid={`improvement-${index}`}>
                  <AlertTriangle className="text-yellow-500 mt-1 h-4 w-4 flex-shrink-0" />
                  <span className="text-muted-foreground">{improvement}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>

        {/* Detailed Breakdown */}
        <div className="mt-8 pt-6 border-t border-border">
          <h3 className="text-lg font-semibold text-foreground mb-4">Detailed Analysis</h3>
          <div className="space-y-4" data-testid="detailed-analysis">
            {Object.entries(analysis.breakdown).map(([key, value]) => {
              const label = key.replace(/([A-Z])/g, ' $1').replace(/^./, str => str.toUpperCase());
              return (
                <div key={key} className="flex justify-between items-center" data-testid={`breakdown-${key}`}>
                  <span className="text-foreground">{label}</span>
                  <div className="flex items-center space-x-2">
                    <div className="w-32 bg-muted rounded-full h-2">
                      <div 
                        className={`h-2 rounded-full ${getProgressBarColor(value)}`}
                        style={{ width: `${value}%` }}
                      ></div>
                    </div>
                    <span className="text-sm font-medium text-foreground w-10 text-right">{value}%</span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Action Buttons */}
        <div className="mt-6 flex justify-center space-x-4">
          <Button onClick={onEditResume} data-testid="button-edit-resume">
            <Edit className="h-4 w-4 mr-2" />
            Edit Resume
          </Button>
          <Button variant="outline" onClick={onDownloadReport} data-testid="button-download-report">
            <Download className="h-4 w-4 mr-2" />
            Download Report
          </Button>
        </div>

        {/* Attempts Remaining */}
        <div className="mt-4 text-center">
          <p className="text-sm text-muted-foreground" data-testid="text-attempts-remaining">
            Attempts remaining: <span className="font-semibold">{attemptsRemaining}/5</span>
          </p>
        </div>
      </CardContent>
    </Card>
  );
}
