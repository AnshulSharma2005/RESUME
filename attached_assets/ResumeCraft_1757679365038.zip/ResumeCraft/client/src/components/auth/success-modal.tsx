import { Dialog, DialogContent } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { CheckCircle } from "lucide-react";

interface SuccessModalProps {
  open: boolean;
  onContinue: () => void;
}

export function SuccessModal({ open, onContinue }: SuccessModalProps) {
  return (
    <Dialog open={open} onOpenChange={() => {}}>
      <DialogContent className="sm:max-w-md text-center" data-testid="success-modal">
        <div className="bg-green-500/10 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
          <CheckCircle className="h-8 w-8 text-green-500" />
        </div>
        
        <h2 className="text-2xl font-bold text-foreground mb-4" data-testid="text-success-title">
          Account Created Successfully!
        </h2>
        
        <p className="text-muted-foreground mb-6" data-testid="text-success-description">
          Welcome to RESUME! You can now start building your perfect resume.
        </p>
        
        <Button 
          onClick={onContinue}
          className="px-6 py-2"
          data-testid="button-continue-dashboard"
        >
          Continue to Dashboard
        </Button>
      </DialogContent>
    </Dialog>
  );
}
