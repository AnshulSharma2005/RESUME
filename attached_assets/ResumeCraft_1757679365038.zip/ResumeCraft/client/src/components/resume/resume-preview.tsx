import { Card } from "@/components/ui/card";
import { cn } from "@/lib/utils";

interface ResumePreviewProps {
  content: any;
  customization: {
    color: string;
    font: string;
    layout: string;
  };
  className?: string;
}

export function ResumePreview({ content, customization, className }: ResumePreviewProps) {
  const accentColors: Record<string, string> = {
    blue: "border-blue-500",
    green: "border-green-500",
    purple: "border-purple-500",
    red: "border-red-500",
    orange: "border-orange-500",
    teal: "border-teal-500",
    pink: "border-pink-500",
    indigo: "border-indigo-500",
    yellow: "border-yellow-500",
    gray: "border-gray-700",
  };
  const accentColor = accentColors[customization.color] || "border-blue-500";

  const skillsBgColors: Record<string, string> = {
    blue: "bg-blue-500/10 text-blue-500",
    green: "bg-green-500/10 text-green-500",
    purple: "bg-purple-500/10 text-purple-500",
    red: "bg-red-500/10 text-red-500",
    orange: "bg-orange-500/10 text-orange-500",
    teal: "bg-teal-500/10 text-teal-500",
    pink: "bg-pink-500/10 text-pink-500",
    indigo: "bg-indigo-500/10 text-indigo-500",
    yellow: "bg-yellow-500/10 text-yellow-500",
    gray: "bg-gray-500/10 text-gray-500",
  };
  const skillsBgColor = skillsBgColors[customization.color] || "bg-blue-500/10 text-blue-500";

  const fontClasses: Record<string, string> = {
    inter: "font-sans",
    times: "font-serif",
    arial: "font-sans",
    helvetica: "font-sans",
    georgia: "font-serif",
  };
  const fontClass = fontClasses[customization.font] || "font-sans";

  return (
    <div className={cn("bg-card rounded-lg p-8 overflow-auto", className)} data-testid="resume-preview">
      <div className="max-w-2xl mx-auto bg-white shadow-lg" style={{ minHeight: "842px", width: "595px" }} id="resume-content">
        <div className={cn("p-8", fontClass)}>
          {/* Header */}
          <div className={cn("border-b-4 pb-4 mb-6", accentColor)}>
            <h1 className="text-3xl font-bold text-gray-900" data-testid="text-resume-name">
              {content?.personalInfo?.name || "Your Name"}
            </h1>
            <p className="text-lg text-gray-600" data-testid="text-resume-title">
              {content?.personalInfo?.title || "Your Professional Title"}
            </p>
            <div className="flex flex-wrap gap-4 mt-2 text-sm text-gray-600">
              <span data-testid="text-resume-email">{content?.personalInfo?.email || "your.email@example.com"}</span>
              <span data-testid="text-resume-phone">{content?.personalInfo?.phone || "(555) 123-4567"}</span>
              <span data-testid="text-resume-location">{content?.personalInfo?.location || "Your City, State"}</span>
            </div>
          </div>

          {/* Professional Summary */}
          {content?.summary && (
            <div className="mb-6">
              <h2 className="text-xl font-semibold text-gray-900 mb-3 border-b border-gray-300 pb-1">
                Professional Summary
              </h2>
              <p className="text-gray-700 leading-relaxed" data-testid="text-resume-summary">
                {content.summary}
              </p>
            </div>
          )}

          {/* Experience */}
          {content?.experience?.length > 0 && (
            <div className="mb-6">
              <h2 className="text-xl font-semibold text-gray-900 mb-3 border-b border-gray-300 pb-1">
                Experience
              </h2>
              {content.experience.map((exp: any, index: number) => (
                <div key={index} className="mb-4" data-testid={`experience-${index}`}>
                  <h3 className="font-semibold text-gray-900">{exp.title}</h3>
                  <p className="text-gray-600">{exp.company} | {exp.duration}</p>
                  <ul className="list-disc list-inside text-gray-700 mt-2 space-y-1">
                    {exp.description?.map((desc: string, descIndex: number) => (
                      <li key={descIndex}>{desc}</li>
                    ))}
                  </ul>
                </div>
              ))}
            </div>
          )}

          {/* Skills */}
          {content?.skills?.length > 0 && (
            <div className="mb-6">
              <h2 className="text-xl font-semibold text-gray-900 mb-3 border-b border-gray-300 pb-1">
                Skills
              </h2>
              <div className="flex flex-wrap gap-2">
                {content.skills.map((skill: string, index: number) => (
                  <span 
                    key={index} 
                    className={cn("px-3 py-1 rounded-full text-sm", skillsBgColor)}
                    data-testid={`skill-${index}`}
                  >
                    {skill}
                  </span>
                ))}
              </div>
            </div>
          )}

          {/* Education */}
          {content?.education?.length > 0 && (
            <div>
              <h2 className="text-xl font-semibold text-gray-900 mb-3 border-b border-gray-300 pb-1">
                Education
              </h2>
              {content.education.map((edu: any, index: number) => (
                <div key={index} data-testid={`education-${index}`}>
                  <h3 className="font-semibold text-gray-900">{edu.degree}</h3>
                  <p className="text-gray-600">{edu.institution} | {edu.year}</p>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
