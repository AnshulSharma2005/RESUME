export interface Template {
  id: string;
  name: string;
  description: string;
  category: "beginner" | "mid-career" | "professional";
  preview: string;
  color: string;
  layout: "single-column" | "two-column";
  style: "modern" | "classic" | "creative" | "minimal";
}

export const templates: Template[] = [
  // Beginner Templates (30)
  ...Array.from({ length: 30 }, (_, i) => ({
    id: `beginner-${i + 1}`,
    name: `Beginner Template ${i + 1}`,
    description: `Clean and simple design perfect for fresh graduates`,
    category: "beginner" as const,
    preview: `bg-gradient-to-br from-blue-50 to-blue-100`,
    color: ["blue", "green", "purple", "teal", "indigo"][i % 5],
    layout: i % 2 === 0 ? "single-column" as const : "two-column" as const,
    style: ["modern", "classic", "minimal"][i % 3] as "modern" | "classic" | "minimal",
  })),
  
  // Mid-career Templates (30)
  ...Array.from({ length: 30 }, (_, i) => ({
    id: `mid-career-${i + 1}`,
    name: `Mid-Career Template ${i + 1}`,
    description: `Professional design for experienced professionals`,
    category: "mid-career" as const,
    preview: `bg-gradient-to-br from-green-50 to-green-100`,
    color: ["green", "blue", "purple", "orange", "red"][i % 5],
    layout: i % 3 === 0 ? "single-column" as const : "two-column" as const,
    style: ["modern", "classic", "creative"][i % 3] as "modern" | "classic" | "creative",
  })),
  
  // Professional Templates (30)
  ...Array.from({ length: 30 }, (_, i) => ({
    id: `professional-${i + 1}`,
    name: `Professional Template ${i + 1}`,
    description: `Executive-level design for senior professionals`,
    category: "professional" as const,
    preview: `bg-gradient-to-br from-purple-50 to-purple-100`,
    color: ["purple", "blue", "gray", "red", "orange"][i % 5],
    layout: i % 4 === 0 ? "single-column" as const : "two-column" as const,
    style: ["modern", "classic", "creative", "minimal"][i % 4] as "modern" | "classic" | "creative" | "minimal",
  })),
];

export const getTemplatesByCategory = (category: string) => {
  return templates.filter(template => template.category === category);
};

export const getTemplateById = (id: string) => {
  return templates.find(template => template.id === id);
};
