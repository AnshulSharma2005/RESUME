export const industryKeywords = {
  software: [
    "JavaScript", "React", "Node.js", "Python", "Java", "SQL", "Git", "AWS", "Docker", "Kubernetes",
    "Machine Learning", "AI", "Full Stack", "Frontend", "Backend", "DevOps", "API", "Database",
    "Agile", "Scrum", "CI/CD", "Microservices", "Cloud Computing", "Software Development"
  ],
  marketing: [
    "Digital Marketing", "SEO", "SEM", "Google Analytics", "Content Marketing", "Social Media",
    "Email Marketing", "PPC", "Brand Management", "Lead Generation", "Conversion Optimization",
    "Market Research", "Campaign Management", "ROI", "KPI", "A/B Testing", "CRM", "Marketing Automation"
  ],
  finance: [
    "Financial Analysis", "Excel", "Financial Modeling", "Budgeting", "Forecasting", "Accounting",
    "Investment Analysis", "Risk Management", "Compliance", "Audit", "Tax", "Corporate Finance",
    "Portfolio Management", "Trading", "Banking", "Insurance", "Regulatory", "Financial Reporting"
  ],
  sales: [
    "B2B Sales", "B2C Sales", "Lead Generation", "Cold Calling", "Relationship Building",
    "Negotiation", "CRM", "Salesforce", "Pipeline Management", "Territory Management",
    "Account Management", "Business Development", "Revenue Growth", "Customer Acquisition",
    "Sales Strategy", "Proposal Writing", "Closing", "Prospecting"
  ],
  healthcare: [
    "Patient Care", "Medical Records", "HIPAA", "Healthcare", "Clinical", "EMR", "EHR",
    "Medical Terminology", "Patient Safety", "Quality Improvement", "Compliance",
    "Healthcare Administration", "Medical Coding", "Nursing", "Pharmaceutical", "Telemedicine"
  ]
};

export const commonSkills = [
  "Communication", "Leadership", "Teamwork", "Problem Solving", "Analytical Skills",
  "Project Management", "Time Management", "Adaptability", "Creativity", "Critical Thinking",
  "Collaboration", "Customer Service", "Attention to Detail", "Multi-tasking", "Organization"
];

export const actionVerbs = [
  "Achieved", "Implemented", "Developed", "Managed", "Led", "Created", "Improved", "Increased",
  "Reduced", "Optimized", "Streamlined", "Delivered", "Launched", "Built", "Designed",
  "Analyzed", "Collaborated", "Coordinated", "Executed", "Facilitated", "Generated",
  "Initiated", "Maintained", "Negotiated", "Organized", "Planned", "Resolved", "Supervised"
];
