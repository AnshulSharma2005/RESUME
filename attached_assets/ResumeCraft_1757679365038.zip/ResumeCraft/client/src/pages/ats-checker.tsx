import { useState, useEffect } from "react";
import { useAuth } from "@/hooks/use-auth";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { FileText, ArrowLeft, LogOut } from "lucide-react";
import logoImage from "@assets/IMG-20231018-WA0066_1757675514497.jpg";
import { UploadArea } from "@/components/ats/upload-area";
import { ATSResults } from "@/components/ats/ats-results";
import { analyzeResume, ATSAnalysis } from "@/utils/ats-scorer";
import { useToast } from "@/hooks/use-toast";
import { logout } from "@/lib/firebase";
import * as pdfjsLib from 'pdfjs-dist';

// Configure PDF.js worker - use CDN to avoid version mismatch
pdfjsLib.GlobalWorkerOptions.workerSrc = `https://cdnjs.cloudflare.com/ajax/libs/pdf.js/4.8.69/pdf.worker.min.js`;

export default function ATSChecker() {
  const { firebaseUser, user, loading } = useAuth();
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  
  const [uploading, setUploading] = useState(false);
  const [analysis, setAnalysis] = useState<ATSAnalysis | null>(null);
  const [attemptsRemaining, setAttemptsRemaining] = useState(5);

  useEffect(() => {
    if (!loading && !firebaseUser) {
      setLocation("/");
    }
  }, [firebaseUser, loading, setLocation]);

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
      </div>
    );
  }

  if (!firebaseUser) return null;

  const extractTextFromPDF = async (file: File): Promise<string> => {
    try {
      const arrayBuffer = await file.arrayBuffer();
      const pdf = await pdfjsLib.getDocument({ data: arrayBuffer }).promise;
      let text = '';
      
      for (let i = 1; i <= pdf.numPages; i++) {
        const page = await pdf.getPage(i);
        const textContent = await page.getTextContent();
        const pageText = textContent.items
          .map((item: any) => item.str)
          .join(' ');
        text += pageText + ' ';
      }
      
      return text.trim();
    } catch (error) {
      console.error('Error extracting PDF text:', error);
      throw new Error('Failed to extract text from PDF. Please ensure it\'s a valid PDF file.');
    }
  };

  const handleFileUpload = async (file: File) => {
    if (attemptsRemaining <= 0) {
      toast({
        title: "No attempts remaining",
        description: "You have used all your ATS check attempts for this session.",
        variant: "destructive",
      });
      return;
    }

    setUploading(true);

    try {
      const resumeText = await extractTextFromPDF(file);
      
      // Simulate processing delay
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      const analysisResult = analyzeResume(resumeText);
      setAnalysis(analysisResult);
      setAttemptsRemaining(prev => prev - 1);
      
      toast({
        title: "Analysis Complete",
        description: `Your resume scored ${analysisResult.score}/100 for ATS compatibility.`,
      });
    } catch (error: any) {
      toast({
        title: "Analysis Failed",
        description: error.message || "Failed to analyze the resume. Please try again.",
        variant: "destructive",
      });
    } finally {
      setUploading(false);
    }
  };

  const handleEditResume = () => {
    setLocation("/customize");
  };

  const handleLogout = async () => {
    try {
      await logout();
      toast({
        title: "Logged out successfully",
        description: "You have been signed out of your account.",
      });
      setLocation("/");
    } catch (error) {
      toast({
        title: "Logout failed",
        description: "There was an error signing out. Please try again.",
        variant: "destructive",
      });
    }
  };

  const handleDownloadReport = () => {
    if (!analysis) return;
    
    const reportData = {
      score: analysis.score,
      breakdown: analysis.breakdown,
      strengths: analysis.strengths,
      improvements: analysis.improvements,
      timestamp: new Date().toISOString()
    };
    
    const blob = new Blob([JSON.stringify(reportData, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'ats-analysis-report.json';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const handleBackToCustomization = () => {
    setLocation("/customize");
  };

  return (
    <div className="min-h-screen bg-background" data-testid="ats-checker-page">
      {/* Navigation */}
      <nav className="bg-card border-b border-border px-6 py-4">
        <div className="max-w-7xl mx-auto flex justify-between items-center">
          <div className="flex items-center space-x-3 hover-grow">
            <div className="relative">
              <img src={logoImage} alt="RESUME Logo" className="h-10 w-10 object-cover rounded-full ring-2 ring-primary/20" />
              <div className="absolute inset-0 bg-gradient-to-br from-purple-500/20 to-blue-600/20 rounded-full animate-float"></div>
            </div>
            <div className="flex flex-col">
              <span className="text-xl font-bold text-gradient">RESUME</span>
              <span className="text-xs text-muted-foreground">Rendition of Skills For Un-Matched Earnings</span>
            </div>
          </div>
          <div className="flex items-center space-x-6">
            <Button 
              variant="ghost" 
              onClick={handleBackToCustomization}
              data-testid="button-back-editor"
            >
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back to Editor
            </Button>
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-3">
                <div className="w-8 h-8 bg-gradient-to-br from-purple-500 to-blue-600 rounded-full flex items-center justify-center">
                  <span className="text-sm font-bold text-white">
                    {(user?.displayName || firebaseUser?.displayName)?.charAt(0) || 'U'}
                  </span>
                </div>
                <span className="text-foreground font-medium text-sm" data-testid="text-user-name">
                  {user?.displayName || firebaseUser?.displayName || 'User'}
                </span>
              </div>
              <Button 
                variant="ghost" 
                size="sm"
                onClick={handleLogout}
                className="text-foreground/60 hover:text-foreground/80 transition-colors"
                data-testid="button-logout"
              >
                <LogOut className="h-4 w-4 mr-2" />
                Logout
              </Button>
            </div>
          </div>
        </div>
      </nav>

      <div className="max-w-4xl mx-auto px-6 py-12">
        {/* Header */}
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold text-foreground mb-4" data-testid="text-ats-title">
            Advanced ATS Score Checker
          </h1>
          <p className="text-base text-muted-foreground mb-4" data-testid="text-ats-description">
            Get instant feedback on how well your resume performs with Applicant Tracking Systems
          </p>
          <div className="bg-card p-6 rounded-xl border mb-6">
            <h2 className="text-lg font-bold text-gradient mb-3">What Our ATS Checker Analyzes:</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
              <div className="flex items-start space-x-2">
                <span className="text-green-500">✓</span>
                <div>
                  <p className="font-medium">Keyword Optimization</p>
                  <p className="text-muted-foreground text-xs">Matches job requirements and industry terms</p>
                </div>
              </div>
              <div className="flex items-start space-x-2">
                <span className="text-green-500">✓</span>
                <div>
                  <p className="font-medium">Format Compatibility</p>
                  <p className="text-muted-foreground text-xs">Clean, parseable structure for ATS systems</p>
                </div>
              </div>
              <div className="flex items-start space-x-2">
                <span className="text-green-500">✓</span>
                <div>
                  <p className="font-medium">Section Organization</p>
                  <p className="text-muted-foreground text-xs">Proper heading structure and content flow</p>
                </div>
              </div>
              <div className="flex items-start space-x-2">
                <span className="text-green-500">✓</span>
                <div>
                  <p className="font-medium">Content Quality</p>
                  <p className="text-muted-foreground text-xs">Professional language and achievement metrics</p>
                </div>
              </div>
            </div>
          </div>
          <div className="bg-gradient-to-r from-primary/10 to-accent/10 p-4 rounded-lg mb-6">
            <p className="text-sm text-muted-foreground">
              <strong>Pro Tip:</strong> Upload your current resume to get a detailed analysis with specific improvement suggestions. Our AI-powered system has been trained on thousands of successful job applications.
            </p>
          </div>
        </div>

        {/* Upload Area or Results */}
        {!analysis ? (
          <UploadArea 
            onFileUpload={handleFileUpload}
            loading={uploading}
          />
        ) : (
          <ATSResults
            analysis={analysis}
            attemptsRemaining={attemptsRemaining}
            onEditResume={handleEditResume}
            onDownloadReport={handleDownloadReport}
          />
        )}

        {/* Try Again Button */}
        {analysis && attemptsRemaining > 0 && (
          <div className="text-center mt-8">
            <Button 
              variant="outline"
              onClick={() => setAnalysis(null)}
              data-testid="button-try-again"
            >
              Check Another Resume
            </Button>
          </div>
        )}

        {/* Usage Information */}
        <div className="mt-8 text-center text-sm text-muted-foreground">
          <p data-testid="text-attempts-info">
            You have {attemptsRemaining} attempts remaining out of 5 per session.
          </p>
        </div>
      </div>
    </div>
  );
}
