import { useState, useEffect } from "react";
import { useAuth } from "@/hooks/use-auth";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { ArrowLeft, Download, LogOut } from "lucide-react";
import { ResumePreview } from "@/components/resume/resume-preview";
import { ColorPicker } from "@/components/customization/color-picker";
import { FontSelector } from "@/components/customization/font-selector";
import { SectionManager } from "@/components/customization/section-manager";
import { getTemplateById } from "@/data/templates";
import { generatePDF } from "@/utils/pdf-generator";
import { useToast } from "@/hooks/use-toast";
import { logout } from "@/lib/firebase";

interface Section {
  id: string;
  name: string;
  visible: boolean;
  order: number;
}

export default function Customization() {
  const { firebaseUser, user, loading } = useAuth();
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  
  // Get template ID from URL
  const urlParams = new URLSearchParams(window.location.search);
  const templateId = urlParams.get('template');
  const template = templateId ? getTemplateById(templateId) : null;

  // Customization state
  const [customization, setCustomization] = useState({
    color: template?.color || 'blue',
    font: 'inter',
    layout: template?.layout || 'two-column'
  });

  // Sample resume content
  const [resumeContent] = useState({
    personalInfo: {
      name: user?.displayName || "Your Name",
      title: "Your Professional Title",
      email: user?.email || "your.email@example.com",
      phone: "(555) 123-4567",
      location: "Your City, State"
    },
    summary: "Experienced professional with expertise in delivering high-quality solutions and driving business success. Proven track record of leadership and innovation in fast-paced environments.",
    experience: [
      {
        title: "Senior Professional",
        company: "Your Company",
        duration: "2021 - Present",
        description: [
          "Led cross-functional teams to deliver successful projects",
          "Improved operational efficiency by 40% through process optimization",
          "Mentored junior team members and contributed to team growth"
        ]
      }
    ],
    skills: ["Leadership", "Project Management", "Strategic Planning", "Team Building", "Problem Solving"],
    education: [
      {
        degree: "Bachelor of Science",
        institution: "Your University",
        year: "2019"
      }
    ]
  });

  const [sections, setSections] = useState<Section[]>([
    { id: 'summary', name: 'Professional Summary', visible: true, order: 1 },
    { id: 'experience', name: 'Experience', visible: true, order: 2 },
    { id: 'skills', name: 'Skills', visible: true, order: 3 },
    { id: 'education', name: 'Education', visible: true, order: 4 },
  ]);

  useEffect(() => {
    if (!loading && !firebaseUser) {
      setLocation("/");
    }
  }, [firebaseUser, loading, setLocation]);

  useEffect(() => {
    if (!firebaseUser || !template) {
      setLocation("/templates");
    }
  }, [firebaseUser, template, setLocation]);

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
      </div>
    );
  }

  if (!firebaseUser || !template) {
    return null;
  }

  const handleColorChange = (color: string) => {
    setCustomization(prev => ({ ...prev, color }));
  };

  const handleLogout = async () => {
    try {
      await logout();
      toast({
        title: "Logged out successfully",
        description: "You have been signed out of your account.",
      });
      setLocation("/");
    } catch (error) {
      toast({
        title: "Logout failed",
        description: "There was an error signing out. Please try again.",
        variant: "destructive",
      });
    }
  };

  const handleFontChange = (font: string) => {
    setCustomization(prev => ({ ...prev, font }));
  };

  const handleSectionToggle = (sectionId: string) => {
    setSections(prev => 
      prev.map(section => 
        section.id === sectionId 
          ? { ...section, visible: !section.visible }
          : section
      )
    );
  };

  const handleSectionReorder = (newSections: Section[]) => {
    setSections(newSections);
  };

  const handleAddSection = () => {
    toast({
      title: "Add Section",
      description: "Section management feature coming soon!",
    });
  };

  const handleDownloadPDF = async () => {
    try {
      await generatePDF('resume-content', `${user?.displayName || 'resume'}_resume.pdf`);
      toast({
        title: "PDF Downloaded",
        description: "Your resume has been downloaded successfully!",
      });

      // Ask if user wants to check ATS score
      const checkATS = window.confirm("Would you like to check your resume's ATS score?");
      if (checkATS) {
        setLocation("/ats-checker");
      }
    } catch (error) {
      toast({
        title: "Download Failed",
        description: "There was an error generating your PDF. Please try again.",
        variant: "destructive",
      });
    }
  };

  const handleBackToTemplates = () => {
    setLocation("/templates");
  };

  return (
    <div className="min-h-screen bg-background" data-testid="customization-page">
      <div className="flex h-screen">
        {/* Resume Preview */}
        <div className="flex-1 p-6 bg-muted/30" data-testid="preview-section">
          <div className="h-full flex flex-col">
            <div className="flex justify-between items-center mb-4">
              <Button 
                variant="ghost" 
                onClick={handleBackToTemplates}
                data-testid="button-back-templates"
              >
                <ArrowLeft className="h-4 w-4 mr-2" />
                Back to Templates
              </Button>
              <div className="flex items-center space-x-4">
                <div className="flex items-center space-x-3">
                  <div className="w-8 h-8 bg-gradient-to-br from-purple-500 to-blue-600 rounded-full flex items-center justify-center">
                    <span className="text-sm font-bold text-white">
                      {(user?.displayName || firebaseUser?.displayName)?.charAt(0) || 'U'}
                    </span>
                  </div>
                  <span className="text-foreground font-medium text-sm" data-testid="text-user-name">
                    {user?.displayName || firebaseUser?.displayName || 'User'}
                  </span>
                </div>
                <Button onClick={handleDownloadPDF} data-testid="button-download-pdf">
                  <Download className="h-4 w-4 mr-2" />
                  Download PDF
                </Button>
                <Button 
                  variant="ghost" 
                  size="sm"
                  onClick={handleLogout}
                  className="text-foreground/60 hover:text-foreground/80 transition-colors"
                  data-testid="button-logout"
                >
                  <LogOut className="h-4 w-4 mr-2" />
                  Logout
                </Button>
              </div>
            </div>
            
            <ResumePreview 
              content={resumeContent}
              customization={customization}
              className="flex-1"
            />
          </div>
        </div>

        {/* Customization Panel */}
        <div className="w-80 bg-card border-l border-border" data-testid="customization-panel">
          <div className="p-6 border-b border-border">
            <h2 className="text-xl font-semibold text-foreground" data-testid="text-panel-title">
              Customize Resume
            </h2>
            <p className="text-muted-foreground text-sm">
              Personalize your resume design
            </p>
          </div>

          <div className="p-6 space-y-6 overflow-auto max-h-[calc(100vh-120px)]">
            {/* Color Customization */}
            <ColorPicker
              selectedColor={customization.color}
              onColorChange={handleColorChange}
            />

            {/* Font Selection */}
            <FontSelector
              selectedFont={customization.font}
              onFontChange={handleFontChange}
            />

            {/* Section Management */}
            <SectionManager
              sections={sections}
              onToggleVisibility={handleSectionToggle}
              onReorder={handleSectionReorder}
              onAddSection={handleAddSection}
            />

            {/* Layout Options */}
            <div>
              <h3 className="font-semibold text-foreground mb-3">Layout Style</h3>
              <div className="grid grid-cols-2 gap-2">
                <Button
                  variant={customization.layout === 'single-column' ? 'default' : 'outline'}
                  className="p-3 h-auto flex-col"
                  onClick={() => setCustomization(prev => ({ ...prev, layout: 'single-column' }))}
                  data-testid="button-layout-single"
                >
                  <div className="bg-muted h-8 w-full rounded mb-2"></div>
                  <span className="text-xs">Single Column</span>
                </Button>
                <Button
                  variant={customization.layout === 'two-column' ? 'default' : 'outline'}
                  className="p-3 h-auto flex-col"
                  onClick={() => setCustomization(prev => ({ ...prev, layout: 'two-column' }))}
                  data-testid="button-layout-two"
                >
                  <div className="flex space-x-1 mb-2 w-full">
                    <div className="bg-primary h-8 w-2/3 rounded"></div>
                    <div className="bg-muted h-8 w-1/3 rounded"></div>
                  </div>
                  <span className="text-xs">Two Column</span>
                </Button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
