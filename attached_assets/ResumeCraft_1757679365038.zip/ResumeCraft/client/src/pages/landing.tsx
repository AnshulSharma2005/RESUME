import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { LoginModal } from "@/components/auth/login-modal";
import { SignupModal } from "@/components/auth/signup-modal";
import { SuccessModal } from "@/components/auth/success-modal";
import { useAuth } from "@/hooks/use-auth";
import { useLocation } from "wouter";
import { FileText, Palette, BarChart3, Download } from "lucide-react";
import logoImage from "@assets/IMG-20231018-WA0066_1757675514497.jpg";

export default function Landing() {
  const [showLogin, setShowLogin] = useState(false);
  const [showSignup, setShowSignup] = useState(false);
  const [showSuccess, setShowSuccess] = useState(false);
  const { firebaseUser } = useAuth();
  const [, setLocation] = useLocation();

  // Redirect if already logged in
  useEffect(() => {
    if (firebaseUser) {
      setLocation("/dashboard");
    }
  }, [firebaseUser, setLocation]);

  // Return null if user is logged in (preventing flash of landing page)
  if (firebaseUser) {
    return null;
  }

  const handleGetStarted = () => {
    setShowSignup(true);
  };

  const handleSignupSuccess = () => {
    setShowSuccess(true);
  };

  const handleContinueToDashboard = () => {
    setShowSuccess(false);
    setLocation("/dashboard");
  };

  return (
    <div className="min-h-screen bg-background" data-testid="landing-page">
      {/* Navigation */}
      <nav className="bg-card/80 backdrop-blur-md border-b border-border/50 px-6 py-4 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto flex justify-between items-center">
          <div className="flex items-center space-x-3 hover-grow">
            <div className="relative">
              <img src={logoImage} alt="RESUME Logo" className="h-8 w-8 object-contain" />
              <div className="absolute inset-0 gradient-purple rounded-full opacity-20 animate-float"></div>
            </div>
            <div className="flex flex-col">
              <span className="text-lg font-bold text-gradient">RESUME</span>
              <span className="text-xs text-muted-foreground">Rendition of Skills For Un-Matched Earnings</span>
            </div>
          </div>
          <div className="flex items-center space-x-6">
            <Button variant="ghost" className="hover-grow text-foreground/80 hover:text-primary transition-colors" data-testid="button-nav-features">Features</Button>
            <Button variant="ghost" className="hover-grow text-foreground/80 hover:text-primary transition-colors" data-testid="button-nav-templates">Templates</Button>
            <Button variant="ghost" className="hover-grow text-foreground/80 hover:text-primary transition-colors" data-testid="button-nav-pricing">Pricing</Button>
            <Button 
              onClick={() => setShowLogin(true)} 
              className="btn-vibrant px-6 py-2 hover-lift text-white"
              data-testid="button-nav-signin"
            >
              Sign In
            </Button>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative overflow-hidden min-h-[80vh] flex items-center">
        {/* Animated gradient background */}
        <div className="absolute inset-0 gradient-rainbow opacity-10 animate-float"></div>
        <div className="absolute inset-0 bg-gradient-to-br from-primary/10 via-accent/5 to-cyan-500/10"></div>
        
        <div className="relative max-w-7xl mx-auto px-6 text-center z-10">
          <div className="animate-bounce-in">
            <h1 className="text-4xl md:text-5xl font-bold mb-4 text-gradient leading-tight" data-testid="text-hero-title">
              Build Your Perfect Resume with AI-Powered ATS Optimization
            </h1>
            <p className="text-lg text-muted-foreground mb-6 max-w-3xl mx-auto leading-relaxed" data-testid="text-hero-description">
              Create professional resumes with our smart templates, customize with ease, and get instant ATS scores to land your dream job.
            </p>
            <div className="flex flex-col sm:flex-row justify-center gap-6">
              <Button 
                size="lg" 
                className="px-8 py-3 text-base font-semibold btn-vibrant hover-lift relative overflow-hidden group text-white"
                onClick={handleGetStarted}
                data-testid="button-get-started"
              >
                <span className="relative z-10">Get Started Free</span>
                <div className="absolute inset-0 bg-gradient-to-r from-purple-600 to-pink-600 opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
              </Button>
              <Button 
                variant="outline" 
                size="lg" 
                className="px-8 py-3 text-base font-semibold border-gradient hover-grow hover-pulse text-primary"
                data-testid="button-view-templates"
              >
                View Templates
              </Button>
            </div>
          </div>
        </div>
        
        {/* Floating elements for visual interest */}
        <div className="absolute top-20 left-20 w-24 h-24 gradient-cyan rounded-full opacity-20 animate-float"></div>
        <div className="absolute top-40 right-32 w-20 h-20 gradient-orange rounded-full opacity-30 animate-float" style={{animationDelay: '1s'}}></div>
        <div className="absolute bottom-32 left-32 w-16 h-16 gradient-green rounded-full opacity-25 animate-float" style={{animationDelay: '2s'}}></div>
        <div className="absolute bottom-20 right-20 w-12 h-12 gradient-purple rounded-full opacity-30 animate-float" style={{animationDelay: '0.5s'}}></div>
      </section>

      {/* Features Section */}
      <section className="py-20 bg-gradient-to-b from-background to-secondary/30">
        <div className="max-w-7xl mx-auto px-6">
          <h2 className="text-3xl font-bold text-center mb-3 text-gradient" data-testid="text-features-title">
            Everything You Need to Build the Perfect Resume
          </h2>
          <p className="text-center text-muted-foreground mb-12 text-base max-w-2xl mx-auto">
            Powerful tools and features to help you create the resume that gets you hired
          </p>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="text-center p-8 bg-card rounded-xl hover-lift border-gradient" data-testid="feature-templates">
              <div className="gradient-purple w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-6 hover-pulse">
                <Palette className="h-10 w-10 text-white" />
              </div>
              <h3 className="text-xl font-bold mb-3 text-gradient">90+ Professional Templates</h3>
              <p className="text-sm text-muted-foreground leading-relaxed">Choose from beginner, mid-career, and professional templates designed by experts and optimized for modern hiring.</p>
            </div>
            
            <div className="text-center p-8 bg-card rounded-xl hover-lift border-gradient" data-testid="feature-ats">
              <div className="gradient-cyan w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-6 hover-pulse">
                <BarChart3 className="h-10 w-10 text-white" />
              </div>
              <h3 className="text-xl font-bold mb-3 text-gradient">ATS Score Checker</h3>
              <p className="text-sm text-muted-foreground leading-relaxed">Get instant feedback on your resume's ATS compatibility with detailed reports and improvement suggestions.</p>
            </div>
            
            <div className="text-center p-8 bg-card rounded-xl hover-lift border-gradient" data-testid="feature-download">
              <div className="gradient-green w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-6 hover-pulse">
                <Download className="h-10 w-10 text-white" />
              </div>
              <h3 className="text-xl font-bold mb-3 text-gradient">Instant PDF Download</h3>
              <p className="text-sm text-muted-foreground leading-relaxed">Download your resume as a high-quality PDF ready for applications with perfect formatting.</p>
            </div>
          </div>
        </div>
      </section>

      {/* How It Works Section */}
      <section className="py-16 bg-background">
        <div className="max-w-7xl mx-auto px-6">
          <h2 className="text-3xl font-bold text-center mb-3 text-gradient" data-testid="text-how-it-works-title">
            How RESUME Works - Simple, Fast, Effective
          </h2>
          <p className="text-center text-muted-foreground mb-12 text-base max-w-2xl mx-auto">
            Create your perfect resume in just 4 easy steps. Our AI-powered platform guides you through each stage.
          </p>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            <div className="text-center p-6 bg-card rounded-xl hover-lift border-gradient" data-testid="step-1">
              <div className="gradient-purple w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4 hover-pulse">
                <span className="text-2xl font-bold text-white">1</span>
              </div>
              <h3 className="text-lg font-bold mb-2 text-gradient">Choose Template</h3>
              <p className="text-sm text-muted-foreground">Select from 90+ professional templates designed for your career level</p>
            </div>
            <div className="text-center p-6 bg-card rounded-xl hover-lift border-gradient" data-testid="step-2">
              <div className="gradient-cyan w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4 hover-pulse">
                <span className="text-2xl font-bold text-white">2</span>
              </div>
              <h3 className="text-lg font-bold mb-2 text-gradient">Add Your Info</h3>
              <p className="text-sm text-muted-foreground">Fill in your details with our smart suggestions and formatting</p>
            </div>
            <div className="text-center p-6 bg-card rounded-xl hover-lift border-gradient" data-testid="step-3">
              <div className="gradient-orange w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4 hover-pulse">
                <span className="text-2xl font-bold text-white">3</span>
              </div>
              <h3 className="text-lg font-bold mb-2 text-gradient">Customize Design</h3>
              <p className="text-sm text-muted-foreground">Personalize colors, fonts, and layout to match your style</p>
            </div>
            <div className="text-center p-6 bg-card rounded-xl hover-lift border-gradient" data-testid="step-4">
              <div className="gradient-green w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4 hover-pulse">
                <span className="text-2xl font-bold text-white">4</span>
              </div>
              <h3 className="text-lg font-bold mb-2 text-gradient">Download & Apply</h3>
              <p className="text-sm text-muted-foreground">Get your ATS-optimized PDF and start applying to jobs</p>
            </div>
          </div>
        </div>
      </section>

      {/* Benefits Section */}
      <section className="py-16 bg-gradient-to-b from-secondary/30 to-background">
        <div className="max-w-7xl mx-auto px-6">
          <h2 className="text-3xl font-bold text-center mb-3 text-gradient" data-testid="text-benefits-title">
            Why Choose RESUME for Your Career Success?
          </h2>
          <p className="text-center text-muted-foreground mb-12 text-base max-w-3xl mx-auto">
            Join thousands of professionals who have successfully landed their dream jobs using our platform
          </p>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <div className="text-center p-6 bg-card rounded-xl hover-lift border-gradient" data-testid="benefit-ats">
              <div className="text-4xl mb-4">🎯</div>
              <h3 className="text-lg font-bold mb-3 text-gradient">98% ATS Pass Rate</h3>
              <p className="text-sm text-muted-foreground leading-relaxed">Our templates are tested with major ATS systems like Workday, Greenhouse, and Lever to ensure maximum compatibility</p>
            </div>
            <div className="text-center p-6 bg-card rounded-xl hover-lift border-gradient" data-testid="benefit-time">
              <div className="text-4xl mb-4">⚡</div>
              <h3 className="text-lg font-bold mb-3 text-gradient">Save 10+ Hours</h3>
              <p className="text-sm text-muted-foreground leading-relaxed">Create professional resumes in minutes, not hours. Our smart suggestions and auto-formatting do the heavy lifting</p>
            </div>
            <div className="text-center p-6 bg-card rounded-xl hover-lift border-gradient" data-testid="benefit-expert">
              <div className="text-4xl mb-4">👨‍💼</div>
              <h3 className="text-lg font-bold mb-3 text-gradient">Expert-Approved</h3>
              <p className="text-sm text-muted-foreground leading-relaxed">All templates designed by professional resume writers and reviewed by hiring managers from top companies</p>
            </div>
            <div className="text-center p-6 bg-card rounded-xl hover-lift border-gradient" data-testid="benefit-success">
              <div className="text-4xl mb-4">📈</div>
              <h3 className="text-lg font-bold mb-3 text-gradient">3x More Interviews</h3>
              <p className="text-sm text-muted-foreground leading-relaxed">Users report getting significantly more interview calls after switching to our professionally-designed resumes</p>
            </div>
            <div className="text-center p-6 bg-card rounded-xl hover-lift border-gradient" data-testid="benefit-industry">
              <div className="text-4xl mb-4">🏭</div>
              <h3 className="text-lg font-bold mb-3 text-gradient">Industry-Specific</h3>
              <p className="text-sm text-muted-foreground leading-relaxed">Templates tailored for different industries - tech, finance, healthcare, marketing, and more</p>
            </div>
            <div className="text-center p-6 bg-card rounded-xl hover-lift border-gradient" data-testid="benefit-support">
              <div className="text-4xl mb-4">🛟</div>
              <h3 className="text-lg font-bold mb-3 text-gradient">24/7 Support</h3>
              <p className="text-sm text-muted-foreground leading-relaxed">Get help whenever you need it with our dedicated support team and comprehensive knowledge base</p>
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section className="py-16 bg-background">
        <div className="max-w-7xl mx-auto px-6">
          <h2 className="text-3xl font-bold text-center mb-3 text-gradient" data-testid="text-testimonials-title">
            Success Stories from Real Users
          </h2>
          <p className="text-center text-muted-foreground mb-12 text-base max-w-2xl mx-auto">
            See how RESUME helped professionals like you land their dream jobs
          </p>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="text-center p-6 bg-card rounded-xl hover-lift border-gradient" data-testid="testimonial-1">
              <div className="w-16 h-16 gradient-purple rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-lg font-bold text-white">SM</span>
              </div>
              <p className="text-sm text-muted-foreground mb-4 italic">"I got 5 interview calls in my first week after updating my resume with RESUME. The ATS scoring feature was a game-changer!"</p>
              <h4 className="text-base font-bold text-gradient">Sarah Martinez</h4>
              <p className="text-xs text-muted-foreground">Software Engineer at Google</p>
            </div>
            <div className="text-center p-6 bg-card rounded-xl hover-lift border-gradient" data-testid="testimonial-2">
              <div className="w-16 h-16 gradient-cyan rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-lg font-bold text-white">DJ</span>
              </div>
              <p className="text-sm text-muted-foreground mb-4 italic">"As a recent graduate, RESUME helped me create a professional-looking resume that got me noticed by top companies."</p>
              <h4 className="text-base font-bold text-gradient">David Johnson</h4>
              <p className="text-xs text-muted-foreground">Marketing Analyst at Microsoft</p>
            </div>
            <div className="text-center p-6 bg-card rounded-xl hover-lift border-gradient" data-testid="testimonial-3">
              <div className="w-16 h-16 gradient-orange rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-lg font-bold text-white">LK</span>
              </div>
              <p className="text-sm text-muted-foreground mb-4 italic">"The career-level specific templates made all the difference. I landed a senior position within 3 weeks of using RESUME."</p>
              <h4 className="text-base font-bold text-gradient">Lisa Kim</h4>
              <p className="text-xs text-muted-foreground">Senior Product Manager at Apple</p>
            </div>
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-16 bg-gradient-to-b from-secondary/30 to-background">
        <div className="max-w-4xl mx-auto px-6">
          <h2 className="text-3xl font-bold text-center mb-3 text-gradient" data-testid="text-faq-title">
            Frequently Asked Questions
          </h2>
          <p className="text-center text-muted-foreground mb-12 text-base">
            Get answers to common questions about our platform
          </p>
          <div className="space-y-6">
            <div className="bg-card p-6 rounded-xl border-gradient" data-testid="faq-1">
              <h3 className="text-lg font-bold mb-2 text-gradient">What makes your templates ATS-friendly?</h3>
              <p className="text-sm text-muted-foreground leading-relaxed">Our templates are designed with clean, parseable formatting that ATS systems can easily read. We avoid complex graphics, tables, and unusual fonts that can confuse parsing algorithms. Every template is tested with major ATS platforms.</p>
            </div>
            <div className="bg-card p-6 rounded-xl border-gradient" data-testid="faq-2">
              <h3 className="text-lg font-bold mb-2 text-gradient">Can I use my resume for different job applications?</h3>
              <p className="text-sm text-muted-foreground leading-relaxed">Absolutely! You can save multiple versions of your resume, customize them for different roles, and our ATS checker helps you optimize each version for specific job postings and companies.</p>
            </div>
            <div className="bg-card p-6 rounded-xl border-gradient" data-testid="faq-3">
              <h3 className="text-lg font-bold mb-2 text-gradient">How accurate is the ATS scoring system?</h3>
              <p className="text-sm text-muted-foreground leading-relaxed">Our ATS scoring system analyzes 50+ factors including keyword density, formatting, section organization, and readability. It's based on extensive testing with real ATS platforms and feedback from hiring managers.</p>
            </div>
            <div className="bg-card p-6 rounded-xl border-gradient" data-testid="faq-4">
              <h3 className="text-lg font-bold mb-2 text-gradient">Do you offer templates for all career levels?</h3>
              <p className="text-sm text-muted-foreground leading-relaxed">Yes! We have specialized templates for beginners (0-2 years), mid-career professionals (2-8 years), and senior executives (8+ years). Each category is optimized for the expectations and requirements of that career stage.</p>
            </div>
            <div className="bg-card p-6 rounded-xl border-gradient" data-testid="faq-5">
              <h3 className="text-lg font-bold mb-2 text-gradient">What file formats can I download?</h3>
              <p className="text-sm text-muted-foreground leading-relaxed">You can download your resume as a high-quality PDF (recommended for applications), Word document (for easy editing), or PNG image. All formats maintain professional formatting and are optimized for both digital and print use.</p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-r from-primary/10 via-accent/5 to-cyan-500/10">
        <div className="max-w-4xl mx-auto px-6 text-center">
          <h2 className="text-4xl font-bold mb-4 text-gradient" data-testid="text-cta-title">
            Ready to Transform Your Career?
          </h2>
          <p className="text-lg text-muted-foreground mb-8 max-w-2xl mx-auto">
            Join thousands of professionals who have successfully landed their dream jobs with RESUME. Start building your perfect resume today.
          </p>
          <div className="flex flex-col sm:flex-row justify-center gap-6">
            <Button 
              size="lg" 
              className="px-12 py-4 text-lg font-semibold btn-vibrant hover-lift relative overflow-hidden group text-white"
              onClick={handleGetStarted}
              data-testid="button-cta-start"
            >
              <span className="relative z-10">Start Building Your Resume</span>
              <div className="absolute inset-0 bg-gradient-to-r from-purple-600 to-pink-600 opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
            </Button>
            <Button 
              variant="outline" 
              size="lg" 
              className="px-12 py-4 text-lg font-semibold border-gradient hover-grow hover-pulse text-primary"
              data-testid="button-cta-learn-more"
            >
              Learn More About Our Features
            </Button>
          </div>
          <p className="text-sm text-muted-foreground mt-6">
            No credit card required • Free to start • Professional results guaranteed
          </p>
        </div>
      </section>

      {/* Modals */}
      <LoginModal
        open={showLogin}
        onClose={() => setShowLogin(false)}
        onShowSignup={() => {
          setShowLogin(false);
          setShowSignup(true);
        }}
      />

      <SignupModal
        open={showSignup}
        onClose={() => setShowSignup(false)}
        onShowLogin={() => {
          setShowSignup(false);
          setShowLogin(true);
        }}
        onSuccess={handleSignupSuccess}
      />

      <SuccessModal
        open={showSuccess}
        onContinue={handleContinueToDashboard}
      />
    </div>
  );
}
