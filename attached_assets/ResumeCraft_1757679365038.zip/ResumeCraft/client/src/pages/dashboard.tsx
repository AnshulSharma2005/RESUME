import { useState, useEffect } from "react";
import { useAuth } from "@/hooks/use-auth";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { FileText, Sprout, TrendingUp, Crown, LogOut } from "lucide-react";
import logoImage from "@assets/IMG-20231018-WA0066_1757675514497.jpg";
import { Card, CardContent } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { logout } from "@/lib/firebase";

export default function Dashboard() {
  const { firebaseUser, user, loading } = useAuth();
  const [, setLocation] = useLocation();
  const [showWelcome, setShowWelcome] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const updateCareerLevelMutation = useMutation({
    mutationFn: (careerLevel: string) =>
      apiRequest("PATCH", "/api/users/career-level", { careerLevel }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/users/me"] });
    },
  });

  useEffect(() => {
    if (!loading && !firebaseUser) {
      setLocation("/");
      return;
    }

    if (user && !showWelcome) {
      setShowWelcome(true);
      toast({
        title: `Welcome back, ${user.displayName || 'there'}!`,
        description: "Ready to create your next professional resume?",
      });

      const timer = setTimeout(() => setShowWelcome(false), 5000);
      return () => clearTimeout(timer);
    }
  }, [firebaseUser, user, loading, showWelcome, setLocation, toast]);

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center relative overflow-hidden">
        <div className="absolute inset-0 gradient-rainbow opacity-5 animate-float"></div>
        <div className="relative z-10 text-center">
          <div className="spinning-rainbow w-16 h-16 rounded-full p-1 mx-auto mb-4">
            <div className="bg-background w-full h-full rounded-full flex items-center justify-center">
              <FileText className="h-8 w-8 text-primary" />
            </div>
          </div>
          <p className="text-muted-foreground animate-pulse">Loading your dashboard...</p>
        </div>
      </div>
    );
  }

  if (!firebaseUser) return null;

  const handleCareerLevelSelection = (level: string) => {
    updateCareerLevelMutation.mutate(level, {
      onSuccess: () => {
        setLocation(`/templates?level=${level}`);
      },
    });
  };

  const handleLogout = async () => {
    try {
      await logout();
      toast({
        title: "Logged out successfully",
        description: "You have been signed out of your account.",
      });
      setLocation("/");
    } catch (error) {
      toast({
        title: "Logout failed",
        description: "There was an error signing out. Please try again.",
        variant: "destructive",
      });
    }
  };

  return (
    <div className="min-h-screen bg-background" data-testid="dashboard-page">
      {/* Navigation */}
      <nav className="bg-card/80 backdrop-blur-md border-b border-border/50 px-6 py-4 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto flex justify-between items-center">
          <div className="flex items-center space-x-3 hover-grow">
            <div className="relative">
              <img src={logoImage} alt="RESUME Logo" className="h-8 w-8 object-contain" />
              <div className="absolute inset-0 gradient-purple rounded-full opacity-20 animate-float"></div>
            </div>
            <div className="flex flex-col">
              <span className="text-lg font-bold text-gradient">RESUME</span>
              <span className="text-xs text-muted-foreground">Rendition of Skills For Un-Matched Earnings</span>
            </div>
          </div>
          <div className="flex items-center space-x-6">
            <Button 
              variant="ghost" 
              className="hover-grow text-foreground/80 hover:text-primary transition-colors"
              data-testid="button-nav-resumes"
            >
              My Resumes
            </Button>
            <Button 
              variant="ghost" 
              className="hover-grow text-foreground/80 hover:text-primary transition-colors"
              data-testid="button-nav-templates"
            >
              Templates
            </Button>
            <Button 
              variant="ghost" 
              className="hover-grow text-foreground/80 hover:text-primary transition-colors"
              onClick={() => setLocation('/ats-checker')}
              data-testid="button-nav-ats"
            >
              ATS Check
            </Button>
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-3 hover-grow">
                <div className="w-10 h-10 gradient-purple rounded-full flex items-center justify-center hover-pulse">
                  <span className="text-sm font-bold text-white">
                    {(user?.displayName || firebaseUser?.displayName)?.charAt(0) || 'U'}
                  </span>
                </div>
                <span className="text-foreground font-medium" data-testid="text-user-name">
                  {user?.displayName || firebaseUser?.displayName || 'User'}
                </span>
              </div>
              <Button 
                variant="ghost" 
                size="sm"
                onClick={handleLogout}
                className="text-foreground/60 hover:text-foreground/80 transition-colors"
                data-testid="button-logout"
              >
                <LogOut className="h-4 w-4 mr-2" />
                Logout
              </Button>
            </div>
          </div>
        </div>
      </nav>

      {/* Welcome Message */}
      <div className="relative overflow-hidden py-12">
        <div className="absolute inset-0 gradient-rainbow opacity-10"></div>
        <div className="absolute inset-0 bg-gradient-to-r from-primary/10 via-accent/5 to-cyan-500/10"></div>
        <div className="relative max-w-7xl mx-auto px-6 text-center">
          <div className="animate-bounce-in">
            <h1 className="text-3xl font-bold mb-3 text-gradient" data-testid="text-welcome-title">
              Welcome back, {user?.displayName?.split(' ')[0] || 'there'}! 🎉
            </h1>
            <p className="text-lg text-muted-foreground" data-testid="text-welcome-description">
              Ready to create your next professional resume?
            </p>
          </div>
        </div>
        
        {/* Floating elements */}
        <div className="absolute top-4 left-10 w-16 h-16 gradient-cyan rounded-full opacity-20 animate-float"></div>
        <div className="absolute top-8 right-16 w-12 h-12 gradient-orange rounded-full opacity-25 animate-float" style={{animationDelay: '1s'}}></div>
      </div>

      {/* Career Level Selection */}
      {!user?.careerLevel && (
        <div className="max-w-4xl mx-auto px-6 py-12" data-testid="career-level-selection">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-3 text-gradient animate-bounce-in" data-testid="text-career-selection-title">
              What best describes your career level?
            </h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto leading-relaxed" data-testid="text-career-selection-description">
              We'll show you templates designed specifically for your experience level.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <Card 
              className="cursor-pointer hover-lift border-gradient bg-gradient-to-br from-card to-green-50/30 group animate-bounce-in"
              onClick={() => handleCareerLevelSelection('beginner')}
              data-testid="card-career-beginner"
              style={{animationDelay: '0.1s'}}
            >
              <CardContent className="p-10 text-center">
                <div className="gradient-green w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-6 hover-pulse group-hover:scale-110 transition-transform">
                  <Sprout className="h-10 w-10 text-white" />
                </div>
                <h3 className="text-xl font-bold text-gradient mb-3">Beginner</h3>
                <p className="text-sm text-muted-foreground leading-relaxed">Fresh graduate or career starter with 0-2 years experience</p>
                <div className="mt-4 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                  <div className="w-full h-1 bg-gradient-to-r from-green-400 to-green-600 rounded-full"></div>
                </div>
              </CardContent>
            </Card>

            <Card 
              className="cursor-pointer hover-lift border-gradient bg-gradient-to-br from-card to-orange-50/30 group animate-bounce-in"
              onClick={() => handleCareerLevelSelection('mid-career')}
              data-testid="card-career-mid"
              style={{animationDelay: '0.2s'}}
            >
              <CardContent className="p-10 text-center">
                <div className="gradient-orange w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-6 hover-pulse group-hover:scale-110 transition-transform">
                  <TrendingUp className="h-10 w-10 text-white" />
                </div>
                <h3 className="text-xl font-bold text-gradient mb-3">Mid-Career</h3>
                <p className="text-sm text-muted-foreground leading-relaxed">Experienced professional with 2-8 years in your field</p>
                <div className="mt-4 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                  <div className="w-full h-1 bg-gradient-to-r from-orange-400 to-orange-600 rounded-full"></div>
                </div>
              </CardContent>
            </Card>

            <Card 
              className="cursor-pointer hover-lift border-gradient bg-gradient-to-br from-card to-purple-50/30 group animate-bounce-in"
              onClick={() => handleCareerLevelSelection('professional')}
              data-testid="card-career-professional"
              style={{animationDelay: '0.3s'}}
            >
              <CardContent className="p-10 text-center">
                <div className="gradient-purple w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-6 hover-pulse group-hover:scale-110 transition-transform">
                  <Crown className="h-10 w-10 text-white" />
                </div>
                <h3 className="text-xl font-bold text-gradient mb-3">Professional</h3>
                <p className="text-sm text-muted-foreground leading-relaxed">Senior expert or leader with 8+ years experience</p>
                <div className="mt-4 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                  <div className="w-full h-1 bg-gradient-to-r from-purple-400 to-purple-600 rounded-full"></div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      )}

      {/* Quick Actions for returning users */}
      {user?.careerLevel && (
        <div className="max-w-6xl mx-auto px-6 py-12" data-testid="quick-actions">
          <h2 className="text-2xl font-bold mb-6 text-gradient">Quick Actions</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <Card 
              className="cursor-pointer hover-lift border-gradient bg-gradient-to-br from-card to-primary/5 group animate-bounce-in"
              onClick={() => setLocation(`/templates?level=${user.careerLevel}`)}
            >
              <CardContent className="p-8">
                <div className="gradient-purple w-12 h-12 rounded-lg flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
                  <FileText className="h-6 w-6 text-white" />
                </div>
                <h3 className="text-lg font-bold text-gradient mb-3">Create New Resume</h3>
                <p className="text-sm text-muted-foreground leading-relaxed">Start with our professional templates</p>
                <div className="mt-4 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                  <div className="w-full h-1 gradient-purple rounded-full"></div>
                </div>
              </CardContent>
            </Card>
            
            <Card 
              className="cursor-pointer hover-lift border-gradient bg-gradient-to-br from-card to-cyan-500/5 group animate-bounce-in"
              onClick={() => setLocation('/ats-checker')}
              style={{animationDelay: '0.1s'}}
            >
              <CardContent className="p-8">
                <div className="gradient-cyan w-12 h-12 rounded-lg flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
                  <TrendingUp className="h-6 w-6 text-white" />
                </div>
                <h3 className="text-lg font-bold text-gradient mb-3">Check ATS Score</h3>
                <p className="text-sm text-muted-foreground leading-relaxed">Analyze your resume's ATS compatibility</p>
                <div className="mt-4 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                  <div className="w-full h-1 gradient-cyan rounded-full"></div>
                </div>
              </CardContent>
            </Card>
            
            <Card 
              className="cursor-pointer hover-lift border-gradient bg-gradient-to-br from-card to-orange-500/5 group animate-bounce-in"
              style={{animationDelay: '0.2s'}}
            >
              <CardContent className="p-8">
                <div className="gradient-orange w-12 h-12 rounded-lg flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
                  <FileText className="h-6 w-6 text-white" />
                </div>
                <h3 className="text-lg font-bold text-gradient mb-3">My Resumes</h3>
                <p className="text-sm text-muted-foreground leading-relaxed">View and edit your saved resumes</p>
                <div className="mt-4 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                  <div className="w-full h-1 gradient-orange rounded-full"></div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      )}
    </div>
  );
}
