import { useState, useEffect } from "react";
import { useAuth } from "@/hooks/use-auth";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { FileText, ArrowLeft, LogOut } from "lucide-react";
import logoImage from "@assets/IMG-20231018-WA0066_1757675514497.jpg";
import { TemplateCard } from "@/components/templates/template-card";
import { templates, getTemplatesByCategory } from "@/data/templates";
import type { Template } from "@/data/templates";
import { logout } from "@/lib/firebase";
import { useToast } from "@/hooks/use-toast";

export default function TemplateGallery() {
  const { firebaseUser, user, loading } = useAuth();
  const [, setLocation] = useLocation();
  const [selectedTemplate, setSelectedTemplate] = useState<string | null>(null);
  
  // Get career level from URL params or user data
  const urlParams = new URLSearchParams(window.location.search);
  const levelFromUrl = urlParams.get('level');
  const careerLevel = levelFromUrl || user?.careerLevel || 'mid-career';
  
  const categoryTemplates = getTemplatesByCategory(careerLevel);

  useEffect(() => {
    if (!loading && !firebaseUser) {
      setLocation("/");
    }
  }, [firebaseUser, loading, setLocation]);

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center relative overflow-hidden">
        <div className="absolute inset-0 gradient-rainbow opacity-5 animate-float"></div>
        <div className="relative z-10 text-center">
          <div className="spinning-rainbow w-16 h-16 rounded-full p-1 mx-auto mb-4">
            <div className="bg-background w-full h-full rounded-full flex items-center justify-center">
              <FileText className="h-8 w-8 text-primary" />
            </div>
          </div>
          <p className="text-muted-foreground animate-pulse">Loading templates...</p>
        </div>
      </div>
    );
  }

  if (!firebaseUser) return null;

  const handleTemplateSelect = (templateId: string) => {
    setSelectedTemplate(templateId);
  };

  const handleCustomizeTemplate = () => {
    if (selectedTemplate) {
      setLocation(`/customize?template=${selectedTemplate}`);
    }
  };

  const handleBackToDashboard = () => {
    setLocation("/dashboard");
  };

  const { toast } = useToast();
  
  const handleLogout = async () => {
    try {
      await logout();
      toast({
        title: "Logged out successfully",
        description: "You have been signed out of your account.",
      });
      setLocation("/");
    } catch (error) {
      toast({
        title: "Logout failed",
        description: "There was an error signing out. Please try again.",
        variant: "destructive",
      });
    }
  };

  return (
    <div className="min-h-screen bg-background" data-testid="template-gallery-page">
      {/* Navigation */}
      <nav className="bg-card/80 backdrop-blur-md border-b border-border/50 px-6 py-4 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto flex justify-between items-center">
          <div className="flex items-center space-x-3 hover-grow">
            <div className="relative">
              <img src={logoImage} alt="RESUME Logo" className="h-8 w-8 object-contain" />
              <div className="absolute inset-0 gradient-purple rounded-full opacity-20 animate-float"></div>
            </div>
            <div className="flex flex-col">
              <span className="text-lg font-bold text-gradient">RESUME</span>
              <span className="text-xs text-muted-foreground">Rendition of Skills For Un-Matched Earnings</span>
            </div>
          </div>
          <div className="flex items-center space-x-6">
            <Button 
              variant="ghost" 
              onClick={handleBackToDashboard}
              className="hover-grow text-foreground/80 hover:text-primary transition-colors"
              data-testid="button-back-dashboard"
            >
              <ArrowLeft className="h-4 w-4 mr-2" />
              Dashboard
            </Button>
            <Button 
              variant="ghost" 
              className="hover-grow text-foreground/80 hover:text-primary transition-colors"
              data-testid="button-nav-resumes"
            >
              My Resumes
            </Button>
            <Button 
              variant="ghost" 
              className="hover-grow text-foreground/80 hover:text-primary transition-colors"
              onClick={() => setLocation('/ats-checker')}
              data-testid="button-nav-ats"
            >
              ATS Check
            </Button>
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-3 hover-grow">
                <div className="w-10 h-10 bg-gradient-to-br from-purple-500 to-blue-600 rounded-full flex items-center justify-center hover-pulse">
                  <span className="text-sm font-bold text-white">
                    {(user?.displayName || firebaseUser?.displayName)?.charAt(0) || 'U'}
                  </span>
                </div>
                <span className="text-foreground font-medium" data-testid="text-user-name">
                  {user?.displayName || firebaseUser?.displayName || 'User'}
                </span>
              </div>
              <Button 
                variant="ghost" 
                size="sm"
                onClick={handleLogout}
                className="text-foreground/60 hover:text-foreground/80 transition-colors"
                data-testid="button-logout"
              >
                <LogOut className="h-4 w-4 mr-2" />
                Logout
              </Button>
            </div>
          </div>
        </div>
      </nav>

      {/* Header Section */}
      <div className="relative overflow-hidden py-12">
        <div className="absolute inset-0 bg-gradient-to-br from-primary/5 via-accent/5 to-cyan-500/5"></div>
        <div className="absolute inset-0 gradient-rainbow opacity-5 animate-float"></div>
        <div className="relative max-w-7xl mx-auto px-6 text-center">
          <div className="animate-bounce-in">
            <h1 className="text-4xl font-bold mb-4 text-gradient" data-testid="text-gallery-title">
              Choose Your Perfect Template ✨
            </h1>
            <p className="text-lg text-muted-foreground mb-3" data-testid="text-gallery-description">
              90+ Professional templates designed for{" "}
            </p>
            <p className="text-sm text-muted-foreground mb-2 max-w-3xl mx-auto">
              Each template is carefully crafted by professional resume writers and tested with major ATS systems including Workday, Greenhouse, Lever, and more. Choose the design that best represents your professional brand.
            </p>
            <div className="inline-block">
              <span className="px-6 py-2 rounded-full bg-gradient-to-r from-primary to-accent text-white font-bold capitalize text-lg" data-testid="text-selected-level">
                {careerLevel.replace('-', ' ')} Professionals
              </span>
            </div>
          </div>
        </div>
      </div>
      
      <div className="max-w-7xl mx-auto px-6 py-8">

        {/* Template Grid */}
        <div className="mb-12">
          <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-6" data-testid="template-grid">
            {categoryTemplates.slice(0, 12).map((template, index) => (
              <div 
                key={template.id} 
                className="animate-bounce-in hover-lift"
                style={{animationDelay: `${index * 0.1}s`}}
              >
                <TemplateCard
                  template={template}
                  onSelect={handleTemplateSelect}
                  selected={selectedTemplate === template.id}
                />
              </div>
            ))}
          </div>
        </div>

        {/* Selection Info */}
        <div className="text-center bg-gradient-to-r from-card to-secondary/30 rounded-2xl p-8 border-gradient">
          <div className="mb-6">
            <div className="inline-block px-4 py-2 bg-gradient-to-r from-primary/10 to-accent/10 rounded-full mb-4">
              <p className="text-sm text-muted-foreground font-medium" data-testid="text-template-count">
                Showing 12 of {categoryTemplates.length} templates optimized for your career level
              </p>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
              <div className="text-center p-4 bg-card rounded-lg border">
                <div className="text-2xl mb-2">📊</div>
                <h3 className="text-base font-bold text-gradient mb-1">ATS-Optimized</h3>
                <p className="text-xs text-muted-foreground">98% ATS compatibility rate</p>
              </div>
              <div className="text-center p-4 bg-card rounded-lg border">
                <div className="text-2xl mb-2">🎨</div>
                <h3 className="text-base font-bold text-gradient mb-1">Fully Customizable</h3>
                <p className="text-xs text-muted-foreground">Colors, fonts, and layout options</p>
              </div>
              <div className="text-center p-4 bg-card rounded-lg border">
                <div className="text-2xl mb-2">👨‍💼</div>
                <h3 className="text-base font-bold text-gradient mb-1">Industry-Specific</h3>
                <p className="text-xs text-muted-foreground">Tailored for different sectors</p>
              </div>
            </div>
          </div>
          
          <div className="space-y-4">
            {selectedTemplate ? (
              <Button 
                size="lg"
                className="px-10 py-4 text-lg font-semibold btn-vibrant hover-lift text-white relative overflow-hidden group"
                onClick={handleCustomizeTemplate}
                data-testid="button-customize-selected"
              >
                <span className="relative z-10">🎨 Customize Selected Template</span>
                <div className="absolute inset-0 bg-gradient-to-r from-purple-600 to-pink-600 opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
              </Button>
            ) : (
              <Button 
                size="lg"
                className="px-10 py-4 text-lg font-semibold btn-vibrant hover-lift text-white relative overflow-hidden group"
                onClick={() => handleTemplateSelect(categoryTemplates[0]?.id)}
                data-testid="button-select-template"
              >
                <span className="relative z-10">✨ Select Template & Customize</span>
                <div className="absolute inset-0 bg-gradient-to-r from-cyan-600 to-purple-600 opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
              </Button>
            )}

            {categoryTemplates.length > 12 && (
              <div>
                <Button 
                  variant="outline" 
                  className="border-gradient hover-grow hover-pulse px-8 py-3"
                  data-testid="button-view-all"
                >
                  View All {categoryTemplates.length} Templates
                </Button>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
