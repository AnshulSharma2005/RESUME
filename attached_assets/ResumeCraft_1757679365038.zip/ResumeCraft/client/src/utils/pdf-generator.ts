import jsPDF from 'jspdf';
import html2canvas from 'html2canvas';

export interface ResumeData {
  personalInfo: {
    name: string;
    title: string;
    email: string;
    phone: string;
    location: string;
  };
  summary: string;
  experience: Array<{
    title: string;
    company: string;
    duration: string;
    description: string[];
  }>;
  education: Array<{
    degree: string;
    institution: string;
    year: string;
  }>;
  skills: string[];
}

export async function generatePDF(elementId: string, filename: string = 'resume.pdf'): Promise<void> {
  const element = document.getElementById(elementId);
  if (!element) {
    throw new Error('Resume element not found');
  }

  try {
    const canvas = await html2canvas(element, {
      scale: 2,
      useCORS: true,
      allowTaint: true,
      backgroundColor: '#ffffff'
    });

    const imgData = canvas.toDataURL('image/png');
    const pdf = new jsPDF('p', 'mm', 'a4');
    
    const imgWidth = 210; // A4 width in mm
    const pageHeight = 295; // A4 height in mm
    const imgHeight = (canvas.height * imgWidth) / canvas.width;
    let heightLeft = imgHeight;
    let position = 0;

    pdf.addImage(imgData, 'PNG', 0, position, imgWidth, imgHeight);
    heightLeft -= pageHeight;

    while (heightLeft >= 0) {
      position = heightLeft - imgHeight;
      pdf.addPage();
      pdf.addImage(imgData, 'PNG', 0, position, imgWidth, imgHeight);
      heightLeft -= pageHeight;
    }

    pdf.save(filename);
  } catch (error) {
    console.error('Error generating PDF:', error);
    throw new Error('Failed to generate PDF. Please try again.');
  }
}

export function generateResumeHTML(data: ResumeData, templateId: string, customization: any): string {
  // This would generate HTML based on the template and customization
  // For now, return a basic structure
  return `
    <div style="font-family: ${customization.font || 'Arial'}, sans-serif; color: ${customization.textColor || '#000'};">
      <div style="border-bottom: 4px solid ${customization.accentColor || '#3b82f6'}; padding-bottom: 16px; margin-bottom: 24px;">
        <h1 style="font-size: 32px; font-weight: bold; margin: 0;">${data.personalInfo.name}</h1>
        <p style="font-size: 18px; color: #666; margin: 4px 0;">${data.personalInfo.title}</p>
        <div style="display: flex; gap: 16px; margin-top: 8px; font-size: 14px; color: #666;">
          <span>${data.personalInfo.email}</span>
          <span>${data.personalInfo.phone}</span>
          <span>${data.personalInfo.location}</span>
        </div>
      </div>
      <!-- Add more sections based on template structure -->
    </div>
  `;
}
