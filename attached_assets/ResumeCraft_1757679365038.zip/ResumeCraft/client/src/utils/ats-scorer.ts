import { industryKeywords, commonSkills, actionVerbs } from "@/data/ats-keywords";

export interface ATSAnalysis {
  score: number;
  strengths: string[];
  improvements: string[];
  breakdown: {
    keywordOptimization: number;
    formatCompatibility: number;
    contentStructure: number;
    readability: number;
  };
}

export function analyzeResume(resumeText: string): ATSAnalysis {
  const text = resumeText.toLowerCase();
  
  // Calculate keyword optimization
  let keywordScore = 0;
  let totalKeywords = 0;
  
  Object.values(industryKeywords).forEach(keywords => {
    keywords.forEach(keyword => {
      totalKeywords++;
      if (text.includes(keyword.toLowerCase())) {
        keywordScore++;
      }
    });
  });
  
  commonSkills.forEach(skill => {
    totalKeywords++;
    if (text.includes(skill.toLowerCase())) {
      keywordScore++;
    }
  });
  
  const keywordOptimization = Math.min((keywordScore / Math.min(totalKeywords, 20)) * 100, 100);
  
  // Calculate action verb usage
  let actionVerbCount = 0;
  actionVerbs.forEach(verb => {
    if (text.includes(verb.toLowerCase())) {
      actionVerbCount++;
    }
  });
  
  // Format compatibility (check for common issues)
  let formatScore = 85; // Base score
  if (text.includes("table") || text.includes("column")) formatScore -= 10;
  if (text.includes("image") || text.includes("graphic")) formatScore -= 5;
  if (text.includes("@") && text.includes(".com")) formatScore += 5; // Has contact info
  
  // Content structure
  const hasContactInfo = text.includes("@") && (text.includes("phone") || text.includes("("));
  const hasExperience = text.includes("experience") || text.includes("work") || text.includes("job");
  const hasEducation = text.includes("education") || text.includes("degree") || text.includes("university");
  const hasSkills = text.includes("skills") || text.includes("technologies");
  
  const contentStructure = [hasContactInfo, hasExperience, hasEducation, hasSkills].filter(Boolean).length * 25;
  
  // Readability
  const wordCount = text.split(/\s+/).length;
  let readability = 70; // Base score
  if (wordCount < 200) readability -= 20;
  if (wordCount > 800) readability -= 10;
  if (actionVerbCount >= 5) readability += 10;
  const quantMatches = text.match(/\d+/g);
  if (quantMatches && quantMatches.length >= 3) readability += 10; // Has quantifiable achievements
  
  const breakdown = {
    keywordOptimization: Math.round(keywordOptimization),
    formatCompatibility: Math.round(formatScore),
    contentStructure: Math.round(contentStructure),
    readability: Math.round(Math.min(readability, 100))
  };
  
  const overallScore = Math.round(
    (breakdown.keywordOptimization + breakdown.formatCompatibility + 
     breakdown.contentStructure + breakdown.readability) / 4
  );
  
  // Generate strengths and improvements
  const strengths: string[] = [];
  const improvements: string[] = [];
  
  if (breakdown.formatCompatibility >= 80) strengths.push("Clean, readable format");
  if (breakdown.keywordOptimization >= 70) strengths.push("Good use of keywords");
  if (hasContactInfo) strengths.push("Contact information clearly visible");
  if (breakdown.contentStructure >= 75) strengths.push("Standard section headings");
  if (actionVerbCount >= 5) strengths.push("Strong action verbs used");
  
  if (breakdown.keywordOptimization < 70) improvements.push("Add more industry-specific keywords");
  const quantifiableMatches = text.match(/\d+/g);
  if (!quantifiableMatches || quantifiableMatches.length < 3) improvements.push("Include quantifiable achievements");
  if (!hasSkills) improvements.push("Consider adding a skills section");
  if (breakdown.readability < 70) improvements.push("Improve content clarity and structure");
  if (actionVerbCount < 3) improvements.push("Use more impactful action verbs");
  
  return {
    score: overallScore,
    strengths,
    improvements,
    breakdown
  };
}
